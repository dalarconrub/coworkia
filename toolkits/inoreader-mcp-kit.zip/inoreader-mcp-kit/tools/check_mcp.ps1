param()

$ErrorActionPreference = "Stop"

$RootDir = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$ServerMain = Join-Path $RootDir "server\main.py"

$CursorCfg = Join-Path $HOME ".cursor\mcp.json"
$ClaudeCfg = Join-Path $HOME ".claude.json"

$Python = $env:PYTHON_BIN
if ([string]::IsNullOrWhiteSpace($Python)) { $Python = "python" }

Write-Host "== check_mcp (inoreader-mcp-kit) =="

if (!(Test-Path $ServerMain)) {
  throw "Falta server/main.py en: $ServerMain"
}
Write-Host "[ok] server/main.py existe"

function Check-Cfg([string]$CfgPath) {
  if (!(Test-Path $CfgPath)) {
    Write-Host "[skip] No existe: $CfgPath"
    return
  }
  $Script = @"
import json, sys
from pathlib import Path
p = Path(r'''$CfgPath''').expanduser()
try:
  data = json.loads(p.read_text(encoding='utf-8'))
except Exception as e:
  print(f'[error] JSON inválido: {p} ({e})')
  sys.exit(1)
srv = (data.get('mcpServers') or {}).get('inoreader-mcp')
if not srv:
  print(f'[warn] No existe mcpServers.inoreader-mcp en {p}')
  sys.exit(0)
args = srv.get('args') or []
print(f'[ok] {p}: mcpServers.inoreader-mcp presente (args[0]={args[0] if args else "∅"})')
"@
  & $Python -c $Script | Write-Host
}

Check-Cfg $CursorCfg
Check-Cfg $ClaudeCfg

Write-Host "[done]"

