#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVER_MAIN="$ROOT_DIR/server/main.py"

CURSOR_CFG="${HOME}/.cursor/mcp.json"
CLAUDE_CFG="${HOME}/.claude.json"

PYTHON_BIN="${PYTHON_BIN:-python3}"

echo "== check_mcp (inoreader-mcp-kit) =="

if [[ -f "$SERVER_MAIN" ]]; then
  echo "[ok] server/main.py existe"
else
  echo "[error] falta server/main.py en $SERVER_MAIN" >&2
  exit 1
fi

check_cfg () {
  local cfg="$1"
  if [[ ! -f "$cfg" ]]; then
    echo "[skip] No existe: $cfg"
    return 0
  fi
  "$PYTHON_BIN" - <<PY
import json, sys
from pathlib import Path
p = Path(r"""$cfg""").expanduser()
try:
  data = json.loads(p.read_text(encoding="utf-8"))
except Exception as e:
  print(f"[error] JSON inválido: {p} ({e})")
  sys.exit(1)
srv = (data.get("mcpServers") or {}).get("inoreader-mcp")
if not srv:
  print(f"[warn] No existe mcpServers.inoreader-mcp en {p}")
  sys.exit(0)
args = srv.get("args") or []
print(f"[ok] {p}: mcpServers.inoreader-mcp presente (args[0]={args[0] if args else '∅'})")
PY
}

check_cfg "$CURSOR_CFG"
check_cfg "$CLAUDE_CFG"

echo "[done]"

