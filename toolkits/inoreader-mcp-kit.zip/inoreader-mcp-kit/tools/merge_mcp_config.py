#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from datetime import datetime


def _load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    raw = path.read_text(encoding="utf-8")
    if not raw.strip():
        return {}
    return json.loads(raw)


def _backup(path: Path) -> Path | None:
    if not path.exists():
        return None
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    backup = path.with_suffix(path.suffix + f".bak.{ts}")
    backup.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
    return backup


def upsert_server(config_path: Path, server_id: str, server_block: dict) -> tuple[Path | None, bool]:
    config = _load_json(config_path)
    if "mcpServers" not in config or not isinstance(config.get("mcpServers"), dict):
        config["mcpServers"] = {}
    prev = config["mcpServers"].get(server_id)
    config["mcpServers"][server_id] = server_block
    backup = _backup(config_path)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return backup, prev != server_block


def remove_server(config_path: Path, server_id: str) -> tuple[Path | None, bool]:
    config = _load_json(config_path)
    servers = config.get("mcpServers")
    if not isinstance(servers, dict) or server_id not in servers:
        return None, False
    backup = _backup(config_path)
    del servers[server_id]
    config_path.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return backup, True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True, help="Ruta al JSON de config (Cursor/Claude Code).")
    ap.add_argument("--server-id", required=True, help="ID del servidor en mcpServers.<id>.")
    ap.add_argument("--mode", choices=["upsert", "remove"], required=True)
    ap.add_argument("--server-block-json", help="JSON del bloque del servidor (solo upsert).")
    args = ap.parse_args()

    config_path = Path(args.config).expanduser()

    if args.mode == "upsert":
        if not args.server_block_json:
            raise SystemExit("--server-block-json es obligatorio en modo upsert")
        server_block = json.loads(args.server_block_json)
        backup, changed = upsert_server(config_path, args.server_id, server_block)
        print(json.dumps({"ok": True, "backup": str(backup) if backup else None, "changed": changed}))
        return

    backup, removed = remove_server(config_path, args.server_id)
    print(json.dumps({"ok": True, "backup": str(backup) if backup else None, "removed": removed}))


if __name__ == "__main__":
    main()

