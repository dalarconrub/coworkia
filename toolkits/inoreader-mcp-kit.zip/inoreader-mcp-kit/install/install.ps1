param(
  [switch]$CursorOnly,
  [switch]$ClaudeOnly
)

$ErrorActionPreference = "Stop"

$RootDir = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$ServerId = "inoreader-mcp"
$ServerMain = (Join-Path $RootDir "server\main.py")

$CursorCfg = Join-Path $HOME ".cursor\mcp.json"
$ClaudeCfg = Join-Path $HOME ".claude.json"

if (!(Test-Path $ServerMain)) {
  throw "No existe server/main.py en: $ServerMain"
}

if ($CursorOnly -and $ClaudeOnly) {
  throw "No puedes usar -CursorOnly y -ClaudeOnly a la vez."
}

Write-Host "== Inoreader MCP Kit installer =="
Write-Host "Este script modificará SOLO tu configuración local (fuera del repo):"
Write-Host "  - $CursorCfg"
Write-Host "  - $ClaudeCfg"
Write-Host "Haré backups automáticos con sufijo .bak.YYYYMMDD_HHMMSS"
Write-Host ""

$AppId = Read-Host "INOREADER_APP_ID"
$AppKey = Read-Host "INOREADER_APP_KEY"
$Username = Read-Host "INOREADER_USERNAME"
$Password = Read-Host "INOREADER_PASSWORD" -AsSecureString

if ([string]::IsNullOrWhiteSpace($AppId) -or [string]::IsNullOrWhiteSpace($AppKey) -or [string]::IsNullOrWhiteSpace($Username)) {
  throw "Todas las credenciales son obligatorias."
}

$PasswordPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
  [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Password)
)
if ([string]::IsNullOrWhiteSpace($PasswordPlain)) {
  throw "INOREADER_PASSWORD es obligatorio."
}

$Python = $env:PYTHON_BIN
if ([string]::IsNullOrWhiteSpace($Python)) { $Python = "python" }

$McpPythonCommand = $env:MCP_PYTHON_COMMAND
if ([string]::IsNullOrWhiteSpace($McpPythonCommand)) { $McpPythonCommand = "python" }

$ServerBlock = @{
  command = $McpPythonCommand
  args    = @($ServerMain)
  env     = @{
    INOREADER_APP_ID  = $AppId
    INOREADER_APP_KEY = $AppKey
    INOREADER_USERNAME = $Username
    INOREADER_PASSWORD = $PasswordPlain
  }
} | ConvertTo-Json -Compress

function Install-One([string]$CfgPath) {
  Write-Host "[info] Instalando en: $CfgPath"
  & $Python (Join-Path $RootDir "tools\merge_mcp_config.py") `
    --config $CfgPath `
    --server-id $ServerId `
    --mode upsert `
    --server-block-json $ServerBlock | Out-Null
  Write-Host "[ok] $CfgPath"
}

if ($ClaudeOnly) {
  Install-One $ClaudeCfg
} elseif ($CursorOnly) {
  Install-One $CursorCfg
} else {
  Install-One $CursorCfg
  Install-One $ClaudeCfg
}

Write-Host ""
Write-Host "[done] Reinicia tu cliente (Cursor / Claude Code) para que cargue el MCP."

