#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVER_ID="inoreader-mcp"

CURSOR_CFG="${HOME}/.cursor/mcp.json"
CLAUDE_CFG="${HOME}/.claude.json"

PYTHON_BIN="${PYTHON_BIN:-python3}"

remove_one () {
  local cfg="$1"
  if [[ ! -f "$cfg" ]]; then
    echo "[skip] No existe: $cfg"
    return 0
  fi
  echo "[info] Eliminando de: $cfg"
  "$PYTHON_BIN" "$ROOT_DIR/tools/merge_mcp_config.py" \
    --config "$cfg" \
    --server-id "$SERVER_ID" \
    --mode remove >/dev/null
  echo "[ok] $cfg"
}

remove_one "$CURSOR_CFG"
remove_one "$CLAUDE_CFG"

echo "[done] Reinicia tu cliente para aplicar cambios."

