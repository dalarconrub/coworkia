param()

$ErrorActionPreference = "Stop"

$RootDir = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$ServerId = "inoreader-mcp"

$CursorCfg = Join-Path $HOME ".cursor\mcp.json"
$ClaudeCfg = Join-Path $HOME ".claude.json"

$Python = $env:PYTHON_BIN
if ([string]::IsNullOrWhiteSpace($Python)) { $Python = "python" }

function Remove-One([string]$CfgPath) {
  if (!(Test-Path $CfgPath)) {
    Write-Host "[skip] No existe: $CfgPath"
    return
  }
  Write-Host "[info] Eliminando de: $CfgPath"
  & $Python (Join-Path $RootDir "tools\merge_mcp_config.py") `
    --config $CfgPath `
    --server-id $ServerId `
    --mode remove | Out-Null
  Write-Host "[ok] $CfgPath"
}

Remove-One $CursorCfg
Remove-One $ClaudeCfg

Write-Host "[done] Reinicia tu cliente para aplicar cambios."

