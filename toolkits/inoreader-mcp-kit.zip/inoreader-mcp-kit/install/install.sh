#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SERVER_ID="inoreader-mcp"
SERVER_MAIN="$ROOT_DIR/server/main.py"

CURSOR_CFG="${HOME}/.cursor/mcp.json"
CLAUDE_CFG="${HOME}/.claude.json"

CURSOR_ONLY=0
CLAUDE_ONLY=0

for arg in "$@"; do
  case "$arg" in
    --cursor-only) CURSOR_ONLY=1 ;;
    --claude-only) CLAUDE_ONLY=1 ;;
    *) ;;
  esac
done

if [[ ! -f "$SERVER_MAIN" ]]; then
  echo "[error] No existe server/main.py en: $SERVER_MAIN" >&2
  exit 1
fi

echo "== Inoreader MCP Kit installer =="
echo "Este script modificará SOLO tu configuración local (fuera del repo):"
echo "  - $CURSOR_CFG"
echo "  - $CLAUDE_CFG"
echo "Haré backups automáticos con sufijo .bak.YYYYMMDD_HHMMSS"
echo

read -r -p "INOREADER_APP_ID: " INOREADER_APP_ID
read -r -p "INOREADER_APP_KEY: " INOREADER_APP_KEY
read -r -p "INOREADER_USERNAME: " INOREADER_USERNAME
read -r -s -p "INOREADER_PASSWORD (no se mostrará): " INOREADER_PASSWORD
echo

if [[ -z "${INOREADER_APP_ID}" || -z "${INOREADER_APP_KEY}" || -z "${INOREADER_USERNAME}" || -z "${INOREADER_PASSWORD}" ]]; then
  echo "[error] Todas las credenciales son obligatorias." >&2
  exit 1
fi

PYTHON_BIN="${PYTHON_BIN:-python3}"

export ROOT_DIR SERVER_MAIN INOREADER_APP_ID INOREADER_APP_KEY INOREADER_USERNAME INOREADER_PASSWORD

SERVER_BLOCK_JSON="$(
  "$PYTHON_BIN" - <<'PY'
import json, os, sys
root_dir = os.environ["ROOT_DIR"]
server_main = os.environ["SERVER_MAIN"]
creds = {
  "INOREADER_APP_ID": os.environ["INOREADER_APP_ID"],
  "INOREADER_APP_KEY": os.environ["INOREADER_APP_KEY"],
  "INOREADER_USERNAME": os.environ["INOREADER_USERNAME"],
  "INOREADER_PASSWORD": os.environ["INOREADER_PASSWORD"],
}
block = {
  "command": os.environ.get("MCP_PYTHON_COMMAND", "python"),
  "args": [server_main],
  "env": creds,
}
print(json.dumps(block))
PY
)"

install_one () {
  local cfg="$1"
  echo "[info] Instalando en: $cfg"
  "$PYTHON_BIN" "$ROOT_DIR/tools/merge_mcp_config.py" \
    --config "$cfg" \
    --server-id "$SERVER_ID" \
    --mode upsert \
    --server-block-json "$SERVER_BLOCK_JSON" >/dev/null
  echo "[ok] $cfg"
}

if [[ $CURSOR_ONLY -eq 1 && $CLAUDE_ONLY -eq 1 ]]; then
  echo "[error] No puedes usar --cursor-only y --claude-only a la vez." >&2
  exit 1
fi

if [[ $CLAUDE_ONLY -eq 1 ]]; then
  install_one "$CLAUDE_CFG"
elif [[ $CURSOR_ONLY -eq 1 ]]; then
  install_one "$CURSOR_CFG"
else
  install_one "$CURSOR_CFG"
  install_one "$CLAUDE_CFG"
fi

echo
echo "[done] Reinicia tu cliente (Cursor / Claude Code) para que cargue el MCP."

