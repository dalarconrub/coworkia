## Troubleshooting

### 1) “Missing required environment variables…”

- Ejecuta de nuevo el instalador del kit (`install/install.ps1` o `install/install.sh`) y completa todas las credenciales.
- Verifica que la entrada `mcpServers.inoreader-mcp.env` existe en tu `~/.cursor/mcp.json` o `~/.claude.json`.

### 2) Errores de autenticación (401 / “Authentication failed”)

- Revisa `INOREADER_USERNAME` y `INOREADER_PASSWORD`.
- Asegúrate de que el `AppId` y `AppKey` son los correctos.
- Si rotaste credenciales, reinstala (el instalador hace merge + backup).

### 3) Timeouts o respuestas vacías

- Reduce el número de artículos pedidos (`limit`) o acota `days`.
- Inoreader puede ir lento; el cliente tiene timeout por defecto (10s).

### 4) El MCP no aparece en el cliente

- Reinicia Cursor / Claude Code tras instalar.
- Ejecuta `tools/check_mcp.ps1` o `tools/check_mcp.sh` para validar:
  - JSON válido
  - entrada `mcpServers.inoreader-mcp`
  - ruta a `server/main.py` existente

### 5) Seguridad (credenciales)

- No copies tu config personal al repo.
- No comitees backups `.bak.*` si generas copias dentro del workspace.

