## Background

Este kit empaqueta un servidor MCP (Model Context Protocol) que expone operaciones de Inoreader como **tools**:

- Listar feeds
- Listar artículos (con filtros: no leídos, por feed, por rango temporal)
- Buscar artículos
- Leer contenido
- Marcar como leído
- Estadísticas

El servidor está implementado en Python y funciona por **stdio** (JSON-RPC).

### Credenciales

Inoreader requiere:

- `INOREADER_APP_ID`
- `INOREADER_APP_KEY`
- `INOREADER_USERNAME`
- `INOREADER_PASSWORD`

Se obtienen creando una app en la sección de developers de Inoreader.

