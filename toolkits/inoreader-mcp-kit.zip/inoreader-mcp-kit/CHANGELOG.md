## Changelog — Inoreader MCP Kit

### 2026-04-28
- Primera versión del toolkit portable (servidor MCP + instaladores + plantillas).

