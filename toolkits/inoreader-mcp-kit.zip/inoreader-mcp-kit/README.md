## Inoreader MCP Kit (toolkit portable)

Toolkit portable para añadir un **servidor MCP de Inoreader** a un proyecto y dejarlo listo para activarlo en **Cursor** y/o **Claude Code** (VSCode/CLI) mediante configuración local del usuario.

Este kit empaqueta el servidor MCP (Python) basado en [`dindicoelho/Inoreader-MCP`](https://github.com/dindicoelho/Inoreader-MCP) y añade instaladores idempotentes (bash + PowerShell) que hacen **backup** y **merge no destructivo** de la configuración.

### Qué resuelve

- Conectar Inoreader (feeds y artículos) como herramientas MCP.
- Instalación reproducible por máquina (sin tocar el repo destino más que añadir esta carpeta).
- Configuración local segura (se guarda en ficheros del HOME del usuario, no en Git).

### Estructura

```text
inoreader-mcp-kit/
├── README.md
├── CHANGELOG.md
├── LICENSE.thirdparty.txt
├── .gitignore
├── docs/
│   ├── BACKGROUND.md
│   └── TROUBLESHOOTING.md
├── server/
│   ├── main.py
│   ├── config.py
│   ├── inoreader_client.py
│   ├── tools.py
│   ├── utils.py
│   ├── requirements.txt
│   └── .env.example
├── templates/
│   ├── cursor-mcp.json
│   └── claude-code-mcp.json
├── install/
│   ├── install.sh
│   ├── install.ps1
│   ├── uninstall.sh
│   └── uninstall.ps1
└── tools/
    ├── check_mcp.sh
    ├── check_mcp.ps1
    └── merge_mcp_config.py
```

### Instalación en otro proyecto

1) Copia la carpeta `inoreader-mcp-kit/` dentro del repo destino (recomendación: `tools/inoreader-mcp-kit/`).

#### bash

```bash
cp -r inoreader-mcp-kit/ /ruta/proyecto-destino/tools/inoreader-mcp-kit
```

#### PowerShell

```powershell
Copy-Item -Recurse -Force inoreader-mcp-kit \ruta\proyecto-destino\tools\inoreader-mcp-kit
```

2) En cada máquina (config local del usuario), ejecuta el instalador:

```bash
# Linux/macOS/Git Bash
bash tools/inoreader-mcp-kit/install/install.sh
```

```powershell
# Windows
powershell -ExecutionPolicy Bypass -File tools\inoreader-mcp-kit\install\install.ps1
```

### Uso diario (ejemplos)

- “Lista mis feeds”
- “Dame los últimos 20 artículos no leídos”
- “Busca artículos sobre <tema> en los últimos 7 días”

### Seguridad (importante)

- **Nunca** guardes credenciales en el repo. El instalador escribe credenciales **solo** en config local del usuario (`~/.cursor/mcp.json`, `~/.claude.json`) con backups automáticos.
- Revisa `docs/TROUBLESHOOTING.md` si hay errores de auth/timeouts.

