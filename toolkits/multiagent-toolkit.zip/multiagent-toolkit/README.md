# tool-kit — Coordinación multiagente + DevLog + Memoria del proyecto

Kit portable para integrar en cualquier proyecto un sistema de coordinación entre **un director humano** y **múltiples agentes IA** (por defecto Claude, Copilot, Codex — raíces; con soporte opcional para **subagentes** `Root/Sub`, p. ej. `Claude/KIT`), con cuatro capas:

1. **Chat compartido diario** (append-only, UTF-8) con marcadores `MEMORIA:`, `BLOQUEO:`, `SIGUIENTE:` y modos de decisión (`VOTO`, `EVAL`, `CERRADO`).
2. **DevLog feature-level append-only** (`devlog/DEVLOG.md`) con CLI de consulta y escritura (`tools/devlog.py`).
3. **Memoria curada del proyecto** (`memory/PURPOSE.md` + `STRUCTURE.md` + `INDEX.md` + `SNAPSHOT.md`) como punto de entrada obligatorio para cualquier agente.
4. **Planificación Scrum** (`multiagents/{models,registry,planner,artifacts}.py` + `tools/sprint.py`) para estructurar el trabajo en sprints con squad multiagente, backlog, task board y persistencia a markdown+json.

Incluye una vista temporal agregada (`tools/timeline.py`) que cruza **chat + devlog + sprints activos** por fecha, derivación automática de memoria desde el chat (`tools/sync_chat_memory.py`) y validación de integridad (`tools/memory_check.py`).

## Qué resuelve

- Contexto cero entre sesiones: el agente siempre sabe qué es el proyecto, dónde están las cosas y qué pasó la semana pasada.
- Trazabilidad: toda decisión (`CERRADO`), hito (`DevLog`) y acuerdo duradero (`MEMORIA:`) queda escrito y recuperable.
- Coordinación sin fricción: el hilo diario es append-only, formateado, y los tres agentes respetan el mismo protocolo.
- Portabilidad: copiar esta carpeta en otro proyecto y rellenar placeholders es suficiente para reutilizarlo íntegro.

## Estructura

```
tool-kit/
├── README.md                       <- este fichero
├── CLAUDE.md                       <- identidad/rol para Claude
├── AGENTS.md                       <- identidad/rol para Codex
├── .claude/
│   └── multiagent.md               <- protocolo compartido (formatos, marcadores, DevLog obligatorio)
├── .github/
│   └── copilot-instructions.md     <- identidad/rol para Copilot
├── memory/
│   ├── INDEX.md                    <- meta-índice de recursos (PASO 1 al arrancar)
│   ├── PURPOSE.md                  <- qué es el proyecto (rellenar)
│   ├── STRUCTURE.md                <- mapa de carpetas (narrativa + TREE auto)
│   ├── ROSTER.md                   <- directorio curado de subagentes activos (Root/Sub)
│   └── SNAPSHOT.md                 <- auto-generado (no existe hasta primer sync-chat-memory)
├── devlog/
│   └── DEVLOG.md                   <- log append-only de hitos
├── chats/
│   └── (chat_YYYY-MM-DD.md se crea automáticamente)
├── multiagents/
│   ├── __init__.py
│   ├── chat_memory.py              <- parser + generador de memoria
│   ├── chat_template.md            <- plantilla del chat diario
│   ├── models.py                   <- dataclasses de sprint (SprintPlan, SprintTask, AgentSpec, ...)
│   ├── registry.py                 <- SCRUM_ROLES + DOMAIN/OPERATION/COORDINATION_AGENTS (personalizar)
│   ├── planner.py                  <- generador de SprintPlan desde objetivo (personalizar keywords)
│   └── artifacts.py                <- serialización sprint ↔ markdown/json
├── tools/
│   ├── init_chat.py                <- resolver chat + briefing (memoria + devlog reciente)
│   ├── devlog.py                   <- append/view sobre DEVLOG.md (campo --sprint opcional)
│   ├── sync_chat_memory.py         <- parsea chat → artifacts + SNAPSHOT.md
│   ├── sprint.py                   <- planificar, listar y consultar sprints
│   ├── timeline.py                 <- agrega chat+devlog+sprints por fecha en artifacts/daily/
│   ├── snapshot_structure.py       <- regenera bloque TREE de STRUCTURE.md
│   ├── memory_check.py             <- valida integridad de memory/
│   └── fix_chat_mojibake.py        <- repara UTF-8 roto
└── artifacts/
    ├── multiagent/                 <- memoria derivada (se llena con sync-chat-memory)
    ├── sprints/                    <- planes de sprint (se llena con sprint.py plan --save)
    └── daily/                      <- timeline diario (se llena con timeline.py)
```

## Instalación en otro proyecto

### bash

```bash
cp -r tool-kit/. /ruta/proyecto-destino/
cd /ruta/proyecto-destino
python tools/init_chat.py   # verifica que todo cargue
```

### PowerShell

```powershell
Copy-Item -Recurse -Force tool-kit\* \ruta\proyecto-destino\
cd \ruta\proyecto-destino
python tools\init_chat.py
```

Luego abre `memory/PURPOSE.md`, `memory/STRUCTURE.md`, `memory/INDEX.md`, `CLAUDE.md` y `AGENTS.md` y busca `TODO:` o `{{...}}` — son los placeholders que debes rellenar con tu proyecto.

## Uso diario (los 3 comandos que más usarás)

```bash
# 1. Al abrir sesión: chat del día + briefing + validación de memory/
python tools/session.py open
#    (si el TREE está desfasado: python tools/session.py open --fix-tree)

# 2. Al cerrar un hito (decisión, feature, bloqueo, revert)
python tools/devlog.py append \
  --agent Claude --area MULTIAGENT --status DONE \
  --title "..." --summary "..." [--refs "CERRADO #N"] [--sprint "<slug>"]

# 3. Al cerrar sesión (tras MEMORIA:/CERRADO en el chat)
python tools/session.py close
```

`session.py` encadena los comandos en el orden correcto y cross-platform:
- `open` = `init_chat` + `memory_check` (no muta artefactos).
- `close` = `sync_chat_memory` + `memory_check` (regenera memoria derivada).

Regla canónica: `sync_chat_memory` pertenece al **cierre**, no a la apertura.
Correrlo al abrir regenera artefactos sin cambios desde el cierre anterior y
puede tapar en silencio un `MEMORIA:` perdido. Si necesitas refrescar tras un
bug, ejecuta `close` explícitamente.

Los comandos subyacentes (`init_chat.py`, `memory_check.py`,
`sync_chat_memory.py`) siguen siendo invocables por separado.

## Sprints (opcional pero integrado)

```bash
# Planificar un sprint (sin --save solo imprime; con --save persiste)
python tools/sprint.py plan "Migrar storage a S3 y cerrar la deuda técnica del módulo X" \
  --name "Sprint Storage v1" --days 14 --save

# Listar sprints persistidos
python tools/sprint.py list

# Estado + task board
python tools/sprint.py status "Sprint Storage v1"

# Timeline los detecta automáticamente (muestra sprints activos por día)
python tools/timeline.py
```

**Cómo se integra con el resto del kit:**
- Cada entrada de devlog puede asociarse al sprint activo con `--sprint <slug>`. El campo se persiste en la entrada y el timeline lo muestra cruzado.
- El chat sigue siendo la fuente viva; el objetivo del sprint se decide allí (`CERRADO`), y al completarse un hito se deja entrada devlog con `--sprint`.
- `artifacts/sprints/<slug>.json` contiene el runtime; `tools/timeline.py` lo lee para detectar qué sprints están vigentes cada día.
- Antes de usarlo en un proyecto real: rellena `multiagents/registry.py` con tus agentes y `multiagents/planner.py` con tus palabras clave y comandos (`_build_task_commands`).

## Reglas operativas clave (invariantes del kit)

1. **Append-only** en `chats/` y `devlog/`. Nunca se reescribe pasado.
2. **UTF-8 estricto** en toda lectura/escritura. En PowerShell usar `-Encoding utf8`.
3. **El chat del día es la única fuente de conversación viva.** Todo lo demás es derivado.
4. **Lectura al arrancar**: `memory/INDEX.md` → `PURPOSE.md` → `STRUCTURE.md` antes que nada.
5. **DevLog obligatorio** tras `CERRADO`, `MEMORIA:` operativa, feature completa, `BLOQUEO/UNBLOCKED`, `REVERT`.
6. **`memory/SNAPSHOT.md` es auto-generado**: no editarlo a mano.
7. **`STRUCTURE.md` TREE es auto-generado** entre marcadores; regenerar con `python tools/snapshot_structure.py` tras cualquier cambio top-level.

## Personalización mínima tras instalar

1. **`tools/devlog.py`** — revisa `ROOT_AGENTS`, `DIRECTOR`, `VALID_AGENTS` y `VALID_AREAS`; añade las áreas propias de tu dominio. Subagentes `Root/Sub` ya se aceptan sin tocar código.
2. **`memory/PURPOSE.md`** — rellena los `TODO:` con la visión y funcionalidades de tu proyecto.
3. **`memory/STRUCTURE.md`** — añade en la narrativa las carpetas que tu proyecto tenga más allá del kit (`agents/`, `apps/`, `docs/`, `data/`, ...).
4. **`memory/INDEX.md`** — amplía las tablas con tus propios recursos (docs de usuario, dashboards, APIs, etc.).
5. **`CLAUDE.md` y `AGENTS.md`** — rellena la sección "Contexto del proyecto".
6. **`multiagents/registry.py`** — añade tus `DOMAIN_AGENTS` (por sistema). Los de `OPERATION_AGENTS` y `COORDINATION_AGENTS` vienen cableados; tócalos solo si cambias roles.
7. **`multiagents/planner.py`** — rellena `SYSTEM_KEYWORDS` con las palabras que el planner debe reconocer en los objetivos, y sobrescribe `_build_task_commands()` para cablear scripts concretos a cada agente.
8. **`tools/timeline.py`** — si tu proyecto tiene artefactos diarios adicionales (logs de sync, runs de CI, etc.), añade secciones en `render_daily()` donde indica `# --- PUNTO DE EXTENSION ---`.

## Extender el kit sin romperlo

- **Nuevas áreas de devlog** → añadir a `VALID_AREAS` en `tools/devlog.py`.
- **Nuevas raíces de agente** → editar `ROOT_AGENTS` en `tools/devlog.py` y en `multiagents/chat_memory.py` (deben coincidir) y ajustar los ficheros de identidad.
- **Subagentes especializados** (`Root/Sub`) → activarlos desde el chat (`**Director [@Root/Sub]:** ...`) y registrarlos en `memory/ROSTER.md`. No requiere editar código.
- **Nuevos artefactos diarios** → extender `render_daily()` en `tools/timeline.py` con una sección nueva.
- **Nuevos marcadores canónicos** (más allá de `MEMORIA`/`BLOQUEO`/`SIGUIENTE`) → actualizar `MEMORY_LINE_RE` en `multiagents/chat_memory.py`.

## Smoke-test recomendado tras instalar

```bash
python tools/session.py open --fix-tree
python tools/devlog.py append --agent Claude --area TOOLING --status DONE \
  --title "Kit instalado" --summary "Verificacion inicial del tool-kit."
python tools/devlog.py view --limit 1
python tools/session.py close
python tools/sprint.py plan "Smoke test" --name "Smoke" --days 1 --save
python tools/sprint.py list
python tools/sprint.py status "Smoke"
python tools/timeline.py
ls artifacts/daily/ artifacts/multiagent/ artifacts/sprints/
```

Si todos los pasos terminan sin error y los directorios `artifacts/` se llenan, el kit está operativo.

## Diseño: por qué esta granularidad

| Capa            | Granularidad          | Razón                                                            |
| --------------- | --------------------- | ---------------------------------------------------------------- |
| `chats/`        | Diario                | La conversación cierra en el día                                 |
| `devlog/`       | Monolítico + archivo mensual | El hito puede durar semanas; partirlo dispersa la narrativa |
| `memory/`       | Monolítico curado     | Describe el estado presente, no una línea temporal               |
| `artifacts/daily/` | Diario (regenerable)  | Vista temporal unificada read-only                               |
| `artifacts/multiagent/` | Snapshot del chat     | Derivado cada vez que se ejecuta sync-chat-memory                |

## Origen

Extraído de [Coworkia](https://github.com/dalarconrub/coworkia) siguiendo el playbook `docs/extract-portable-toolkit.md`. Cualquier bug detectado en el kit debe corregirse también en el proyecto origen si procede.
