# Protocolo Multiagente Compartido

Este archivo define la capa de coordinación entre los agentes IA del proyecto (por defecto Claude, Copilot y Codex — agentes **raíz**) y sus **subagentes** (`Root/Sub`).

## Memoria del proyecto — PASO 1 al arrancar

Antes de leer nada más, todo agente debe cargar la memoria curada del proyecto:

1. `memory/INDEX.md` — mapa de todos los recursos.
2. `memory/PURPOSE.md` — qué es el proyecto y qué hace.
3. `memory/STRUCTURE.md` — organización de carpetas y lógica.

Solo después se lee el archivo de identidad propio (`CLAUDE.md` / `AGENTS.md` / `.github/copilot-instructions.md`) y esta misma guía.

Si detectas desalineación entre `memory/*.md` y el estado real del repo, corrígelo en el mismo turno y deja entrada `[DOCS]` en el devlog. `memory/STRUCTURE.md` se regenera con `python tools/snapshot_structure.py` (el bloque TREE, la narrativa se edita a mano).

## Precedencia: memoria del repo sobre memoria del harness

Las memorias locales del harness (Codex memories en `~/.codex/memories/`, Claude profile memory, caches similares de otros harnesses) **nunca sustituyen** a la memoria versionada del repo. Son una capa auxiliar de recall, no una fuente de verdad.

Ante conflicto entre lo que "recuerda" tu harness y lo que dice el repo, **mandan** (en orden):

1. `AGENTS.md` / `CLAUDE.md` / `.github/copilot-instructions.md` (identidad y protocolo).
2. `memory/*.md` (`INDEX`, `PURPOSE`, `STRUCTURE`, `ROSTER`, `SNAPSHOT`).
3. Chat del día (`chats/chat_YYYY-MM-DD.md`).
4. `devlog/DEVLOG.md`.

Si el harness expone gestión de memorias (p. ej. `/memories` en Codex), limpia o ignora recuerdos locales obsoletos cuando los detectes. No hace falta crear `.codex/` ni carpetas paralelas por cada harness: el contrato project-scoped ya vive en `AGENTS.md` + este protocolo.

## Apertura y cierre de sesión

El flujo canónico del día está cableado en `tools/session.py` (cross-platform, sin `.bat`/`.sh` paralelos):

```bash
python tools/session.py open      # init_chat + memory_check
python tools/session.py close     # sync_chat_memory + memory_check
```

- **Apertura no muta artefactos**: solo resuelve el chat del día, imprime briefing y valida `memory/`.
- **Cierre regenera memoria derivada**: corre `sync_chat_memory` (artifacts + `memory/SNAPSHOT.md`) y revalida `memory/`.
- **Regla de oro**: `sync_chat_memory` pertenece al cierre, no a la apertura. Correrlo al abrir es cargo-cult.
- Si memory_check detecta TREE desfasado, repetir con `python tools/session.py open --fix-tree`.

Los comandos subyacentes (`tools/init_chat.py`, `tools/memory_check.py`, `tools/sync_chat_memory.py`) siguen siendo invocables por separado cuando haga falta.

## Fuente de verdad — conversación

- Hay un chat por día en `chats/chat_YYYY-MM-DD.md`.
- Para resolver la ruta del chat del día (creándolo desde plantilla si no existe):
  `python tools/init_chat.py` → imprime la ruta activa + briefing (memoria + últimas entradas del devlog).
  (En el día a día usa `python tools/session.py open`; este comando llama a `init_chat` internamente.)
- La plantilla canónica es `multiagents/chat_template.md`.
- Los chats de días anteriores se preservan en `chats/` como histórico.
- Cada agente debe leer el chat del día completo antes de responder.
- El hilo es append-only: nunca se editan ni borran mensajes previos.
- Todos los chats deben mantenerse en `UTF-8`.
- En `Windows PowerShell 5.1`, cualquier lectura o escritura manual sobre los ficheros de `chats/` debe usar `-Encoding utf8`.
- Los scripts que escriban en un chat deben declarar `encoding="utf-8"` explícitamente.
- Si aparece mojibake, repararlo con `python tools/fix_chat_mojibake.py <ruta>`.

## Cuándo responde un agente

Un agente responde solo si se cumple alguna:

1. El director lo menciona directamente como `**Director [@Agente]:**` (la raíz o un subagente).
2. Hay una decisión abierta esperando su evaluación o voto.
3. Otro agente lo menciona explícitamente (`@Root` o `@Root/Sub`).

Si el director dirige a un subagente (`@Claude/KIT`), solo responde ese subagente; la raíz no asume el turno salvo nueva mención.

Un agente no debe responder dos veces a la misma decisión abierta salvo que:

- haya nueva información relevante
- el director lo vuelva a mencionar
- otro agente le pida una réplica concreta

## Formato común

```md
**Director [@Destinatario]:** mensaje
**Copilot:** mensaje
**Claude:** mensaje
**Codex:** mensaje
```

`Destinatario` puede ser una raíz (`Claude`/`Copilot`/`Codex`) o un subagente (`Claude/KIT`, `Codex/INX`, ...). Las menciones laterales `@Root` y `@Root/Sub` funcionan igual.

Regla de estilo:

- mensajes cortos
- una intención por mensaje
- mención explícita al siguiente owner cuando proceda

## Subagentes (`Root/Sub`)

Un subagente es una variante especializada de una raíz. Hereda su protocolo y se dirige a un dominio o tarea concreta.

- Notación: `Root/Sub` — `Root` ∈ `ROOT_AGENTS` (por defecto `Claude`/`Copilot`/`Codex`); `Sub` = letras/dígitos/`_`/`-`.
- Firma del mensaje: `**Claude/KIT:**`, `**Codex/INX:**`, etc.
- Dirección desde el director: `**Director [@Claude/KIT]:** ...`.
- Mención lateral: `@Claude/KIT`.
- Identidad de primera clase en `tools/devlog.py` (`--agent Claude/KIT`) y en `multiagents/chat_memory.py` (parser y estado por agente).
- Directorio vigente de subagentes: [`memory/ROSTER.md`](../memory/ROSTER.md). Solo entran subagentes activados por el director o confirmados con `✅ CERRADO`.
- Herencia: el subagente aplica el `CLAUDE.md` / `AGENTS.md` / `.github/copilot-instructions.md` de su raíz + este protocolo. No redefine reglas base.
- Handoff: si la pregunta se sale del foco declarado, el subagente hace `SIGUIENTE: @Root` (o @otro subagente) y no fuerza respuesta.
- Personalizar raíces: edita `ROOT_AGENTS` en `multiagents/chat_memory.py` y `tools/devlog.py` (deben coincidir).

## Marcadores canónicos

Estos marcadores permiten memoria estructurada y logs:

```md
MEMORIA: hecho o acuerdo duradero
BLOQUEO: impedimento concreto
SIGUIENTE: siguiente acción u owner
```

Ejemplo:

```md
**Claude:** 🔍 EVAL #4 desde análisis: C > A > B.
MEMORIA: la autoridad canónica de <recurso> sigue siendo <sistema>.
SIGUIENTE: @Codex aterriza el cambio de implementación.
```

## Modos de decisión

### 🗳️ VOTO

```md
🗳️ VOTO #N: ✅/❌ [razón breve]
```

### 🔍 EVALUACIÓN

Claude usa:

```md
🔍 EVAL #N desde análisis: [valoración]. Ranking: X > Y > Z
```

Copilot usa:

```md
🔍 EVAL #N desde orquestación: [valoración]. Ranking: X > Y > Z
```

Codex usa:

```md
🔍 EVAL #N desde implementación: [valoración]. Ranking: X > Y > Z
```

### 🎯 ESPECIALIDAD

Solo el director puede delegarla.

```md
✅ CERRADO: [decisión adoptada]
```

### 💡 CREATIVIDAD

Formato libre, pero con propuestas concretas.

## Cierre y memoria

Cuando una conversación deja acuerdos o estado operativo relevante, cualquier agente puede recomendar cerrar la sesión:

```bash
python tools/session.py close        # sync + memory_check
# o, si solo quieres el sync sin revalidar:
python tools/sync_chat_memory.py
```

Ese comando genera:

- `artifacts/multiagent/conversation_records.jsonl`
- `artifacts/multiagent/decision_log.json`
- `artifacts/multiagent/agent_state.json`
- `artifacts/multiagent/memory_records.json`
- `artifacts/multiagent/chat_memory_snapshot.json`
- `artifacts/multiagent/chat_memory.md`
- `memory/SNAPSHOT.md` — agregado de `MEMORIA`/`BLOQUEO`/`SIGUIENTE` de todos los chats

## DevLog obligatorio

El log de desarrollo feature-level vive en `devlog/DEVLOG.md` (append-only, UTF-8). Complementa a `git log` (commits) y al chat del día (conversación): narra *qué se trabajó, por qué y con qué impacto*.

### Lectura inicial

Todos los agentes deben, al arrancar, leer las **últimas ~20 entradas** para tener contexto de trabajo reciente:

```bash
python tools/devlog.py view --limit 20
```

### Escritura obligatoria

Un agente **debe** añadir entrada al devlog cuando, en el mismo turno:

1. Cierra una decisión con `✅ CERRADO #N`.
2. Registra una `MEMORIA:` duradera con impacto operativo.
3. Completa una tarea de código con cambios mergeados (hito de feature).
4. Registra un `BLOQUEO:` real (`Estado: BLOCKED`); al resolverse, otro `UNBLOCKED`.
5. Hace `REVERT` o rollback significativo.

No se escribe entrada para refactors menores, fixes triviales o ediciones sin impacto en comportamiento.

### Cómo escribir

Usar el helper (garantiza UTF-8, timestamp UTC y enlace al chat del día):

```bash
python tools/devlog.py append \
  --agent Claude --area MULTIAGENT --status DONE \
  --title "Descripción breve del hito" \
  --summary "Qué cambió, por qué, impacto." \
  [--commits sha1,sha2] [--refs "CERRADO #N"] [--sprint "<nombre>"]
```

Áreas por defecto: `MULTIAGENT`, `TOOLING`, `DOCS`, `INFRA`, `GENERAL`. Añade las específicas de tu dominio editando `VALID_AREAS` en `tools/devlog.py`.
Estados: `START`, `PROGRESS`, `BLOCKED`, `UNBLOCKED`, `DONE`, `REVERT`.
Campo opcional `Sprint:` para cruzar con ciclos de trabajo si los usas.

### Consulta

```bash
python tools/devlog.py view                         # últimas 20
python tools/devlog.py view --area MULTIAGENT
python tools/devlog.py view --agent Codex --limit 5
python tools/devlog.py view --status BLOCKED        # bloqueos vigentes
```

### Vista temporal (cross-capa)

Para unificar chat + devlog + sprints de una fecha o rango:

```bash
python tools/timeline.py                    # hoy
python tools/timeline.py --date 2026-04-18
python tools/timeline.py --days 7           # últimos 7 días
python tools/timeline.py --from 2026-04-15 --to 2026-04-18
```

Escribe `artifacts/daily/YYYY-MM-DD.md` (regenerable, read-only sobre fuentes). Los sprints activos se detectan leyendo `artifacts/sprints/*.json` y filtrando por fecha (`start_date <= día <= end_date`).

## Sistema de sprints

Planificación Scrum sobre el proyecto. Vive en `multiagents/*.py` y se maneja desde `tools/sprint.py`.

### CLI

```bash
# Planificar un sprint (objetivo en lenguaje natural)
python tools/sprint.py plan "Integrar nuevo pipeline de ingesta" \
  --name "Sprint Ingesta v1" --days 14 --save

# Listar sprints persistidos
python tools/sprint.py list

# Estado de un sprint
python tools/sprint.py status "Sprint Ingesta v1"
```

`--save` persiste el plan a `artifacts/sprints/<slug>.md` + `.json`. Sin `--save`, solo imprime el plan al stdout (útil para revisar antes de comprometerse).

### Integración con el resto del kit

- **Devlog ↔ Sprint.** Al completar un hito que forma parte del ciclo activo, asocia la entrada al sprint con `--sprint <slug>`:
  ```bash
  python tools/devlog.py append --agent Claude --area GENERAL --status DONE \
      --title "Pipeline base conectado" --summary "..." \
      --sprint "sprint-ingesta-v1" --refs "CERRADO #N"
  ```
- **Chat ↔ Sprint.** El objetivo del sprint y sus cierres (`CERRADO`) se discuten en el chat del día normalmente. Cuando se cierra un hito de sprint, el agente deja `MEMORIA:` si procede, entrada `[AREA]` en el devlog con `--sprint` y opcionalmente ejecuta `python tools/sync_chat_memory.py`.
- **Timeline ↔ Sprint.** `tools/timeline.py` escanea `artifacts/sprints/*.json` y muestra los sprints activos cada día (fecha entre `start_date` y `end_date`), cruzándolos con las entradas del devlog que tengan el campo `Sprint:`.

### Personalización del planner

Antes de usar en un proyecto real, edita:

1. **`multiagents/registry.py`** — añade tus `DOMAIN_AGENTS` (por sistema) y `OPERATION_AGENTS` adicionales (más allá de triage y reporting que vienen cableados).
2. **`multiagents/planner.py`** — rellena `SYSTEM_KEYWORDS` para que el planner infiera los sistemas relevantes desde la descripción del objetivo, y sobreescribe `_build_task_commands()` para cablear scripts concretos del proyecto a cada agente.

Sin personalización, el kit produce sprints válidos pero mínimos: coordinación + triage + reporting + un backlog genérico de 3 items (`PB-001..003`).
