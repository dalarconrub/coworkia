"""
Sesion multiagente: apertura y cierre del flujo del dia.

Encadena los tres comandos del kit en el orden correcto y cross-platform
(Windows / macOS / Linux). Un unico punto de entrada para evitar scripts
`.bat` / `.sh` paralelos que se desincronizan.

Apertura (inicio de trabajo):
  1. init_chat.py         -> resuelve/crea chat del dia + imprime briefing
                             (memoria + ultimas entradas del devlog).
  2. memory_check.py      -> valida memory/ (ficheros, enlaces, TREE al dia).

Cierre (fin de trabajo):
  1. sync_chat_memory.py  -> regenera `artifacts/multiagent/*` y
                             `memory/SNAPSHOT.md` leyendo el chat del dia.
  2. memory_check.py      -> revalida memory/ tras el sync.

Regla de oro: `sync_chat_memory` pertenece al CIERRE, no a la apertura.
Correrlo al abrir es cargo-cult: regenera artifacts sin cambios desde el
cierre anterior y, si en ese cierre se perdio un `MEMORIA:`, lo tapa en
silencio.

Uso:
    python tools/session.py open      # apertura (no muta artifacts)
    python tools/session.py close     # cierre (regenera memoria derivada)
    python tools/session.py open --fix-tree   # regenera TREE si esta desfasado

Codigos de salida:
    0  OK.
    1  init_chat o sync_chat_memory fallo.
    2  memory_check detecto desalineacion (no fatal; corregir antes de trabajar).
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
_TOOLS = _ROOT / "tools"


def _run(step: str, argv: list[str]) -> int:
    print(f"[{step}] {' '.join(argv)}")
    completed = subprocess.run([sys.executable, *argv], cwd=_ROOT)
    return completed.returncode


def cmd_open(fix_tree: bool) -> int:
    print("=== Apertura de sesion ===\n")

    print("[1/2] init_chat: resolviendo chat del dia y briefing...")
    rc = _run("init_chat", [str(_TOOLS / "init_chat.py")])
    if rc != 0:
        print("\n[ERROR] init_chat.py fallo. Revisa chats/ y multiagents/chat_template.md.")
        return 1

    print("\n[2/2] memory_check: validando memory/...")
    check_argv = [str(_TOOLS / "memory_check.py")]
    if fix_tree:
        check_argv.append("--fix-tree")
    rc = _run("memory_check", check_argv)
    if rc != 0:
        print(
            "\n[WARN] memory_check detecto desalineacion.\n"
            "       Reintenta con `python tools/session.py open --fix-tree` "
            "si el problema es TREE desfasado,\n"
            "       o corrige manualmente los enlaces rotos antes de trabajar."
        )
        return 2

    print("\nApertura OK. Chat del dia y memory/ listos.")
    return 0


def cmd_close() -> int:
    print("=== Cierre de sesion ===\n")

    print("[1/2] sync_chat_memory: regenerando artifacts/multiagent y memory/SNAPSHOT.md...")
    rc = _run("sync_chat_memory", [str(_TOOLS / "sync_chat_memory.py")])
    if rc != 0:
        print("\n[ERROR] sync_chat_memory fallo. Revisa el chat del dia y reintenta.")
        return 1

    print("\n[2/2] memory_check: validando memory/...")
    rc = _run("memory_check", [str(_TOOLS / "memory_check.py")])
    if rc != 0:
        print("\n[WARN] memory_check detecto desalineacion despues del sync.")
        return 2

    print("\nCierre OK. Memoria derivada al dia.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    ap_open = sub.add_parser("open", help="Apertura: init_chat + memory_check")
    ap_open.add_argument(
        "--fix-tree",
        action="store_true",
        help="Si memory_check detecta TREE desfasado, regenerarlo (propaga a snapshot_structure.py).",
    )

    sub.add_parser("close", help="Cierre: sync_chat_memory + memory_check")

    args = parser.parse_args()

    if args.cmd == "open":
        return cmd_open(fix_tree=args.fix_tree)
    if args.cmd == "close":
        return cmd_close()
    return 2


if __name__ == "__main__":
    sys.exit(main())
