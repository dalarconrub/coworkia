"""
Sprint CLI autonomo del tool-kit.

Subcomandos:
  plan    <goal> [--name ...] [--start YYYY-MM-DD] [--days N] [--save]
  status  <name>              Muestra SprintPlan + estado de tareas persistido
  list                        Lista todos los sprints en artifacts/sprints/

El fichero que se persiste al guardar (`--save`) es `artifacts/sprints/<slug>.{md,json}`.
Timeline (tools/timeline.py) lee estos ficheros para mostrar sprints activos por dia.

Integra con el resto del tool-kit:
  - Un CERRADO de sprint en el chat => entrada [GENERAL] DONE en el devlog con
    --sprint <slug>. El timeline cruza automaticamente.
  - tools/devlog.py append acepta --sprint para asociar hitos al ciclo activo.
  - tools/sync_chat_memory.py sigue funcionando sin cambios.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from datetime import date as Date
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))

from multiagents.artifacts import (  # noqa: E402
    create_sprint_run,
    load_sprint_run,
    render_sprint_markdown,
    sprint_paths,
    write_sprint_artifact,
    write_sprint_run_artifacts,
)
from multiagents.planner import plan_sprint  # noqa: E402

SPRINTS_DIR = _ROOT / "artifacts" / "sprints"


def cmd_plan(args: argparse.Namespace) -> int:
    start = Date.fromisoformat(args.start) if args.start else None
    plan = plan_sprint(args.goal, sprint_name=args.name, start_date=start, duration_days=args.days)
    print(render_sprint_markdown(plan))
    if args.save:
        run = create_sprint_run(plan)
        md_path, json_path = write_sprint_run_artifacts(run, output_dir=str(SPRINTS_DIR))
        print()
        print(f"Guardado: {md_path}")
        print(f"Guardado: {json_path}")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    try:
        run = load_sprint_run(args.name, output_dir=str(SPRINTS_DIR))
    except FileNotFoundError:
        raise SystemExit(f"No existe sprint guardado con nombre '{args.name}' en {SPRINTS_DIR}")

    md_path, _ = sprint_paths(run.plan.sprint_name, output_dir=str(SPRINTS_DIR))
    print(f"Sprint: {run.plan.sprint_name}  ({run.plan.status})")
    print(f"Fechas: {run.plan.start_date} -> {run.plan.end_date}")
    print(f"Objetivo: {run.plan.objective}")
    print(f"Fichero: {md_path}")
    print()
    print("Task board:")
    for state in run.task_states:
        print(f"  - {state.task_key}: {state.status}")
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    if not SPRINTS_DIR.exists():
        print("(sin sprints persistidos)")
        return 0
    jsons = sorted(SPRINTS_DIR.glob("*.json"))
    if not jsons:
        print("(sin sprints persistidos)")
        return 0
    for p in jsons:
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            plan = data.get("plan", {})
            name = plan.get("sprint_name", p.stem)
            status = plan.get("status", "unknown")
            start = plan.get("start_date", "?")
            end = plan.get("end_date", "?")
            print(f"- {name}  [{status}]  {start} -> {end}  ({p.name})")
        except Exception as exc:
            print(f"- {p.name}  (no parseable: {exc})")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="cmd", required=True)

    ap_plan = sub.add_parser("plan", help="Generar un SprintPlan desde un objetivo")
    ap_plan.add_argument("goal", help="Objetivo del sprint en lenguaje natural")
    ap_plan.add_argument("--name", default="Sprint 1", help="Nombre del sprint")
    ap_plan.add_argument("--start", default=None, help="Fecha inicio YYYY-MM-DD (por defecto hoy)")
    ap_plan.add_argument("--days", type=int, default=14, help="Duracion en dias")
    ap_plan.add_argument("--save", action="store_true", help="Persistir a artifacts/sprints/")

    ap_status = sub.add_parser("status", help="Mostrar estado de un sprint persistido")
    ap_status.add_argument("name", help="Nombre del sprint")

    sub.add_parser("list", help="Listar sprints persistidos")

    args = parser.parse_args()
    if args.cmd == "plan":
        return cmd_plan(args)
    if args.cmd == "status":
        return cmd_status(args)
    if args.cmd == "list":
        return cmd_list(args)
    return 2


if __name__ == "__main__":
    sys.exit(main())
