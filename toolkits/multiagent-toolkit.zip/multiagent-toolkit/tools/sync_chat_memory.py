"""
Sync-chat-memory: parsea el chat del dia y genera la memoria multiagente.

CLI autonomo del kit (equivalente a `orchestrator_agent.py sync-chat-memory`
cuando el kit se integra en un proyecto mayor).

Produce:
  artifacts/multiagent/
    - conversation_records.jsonl
    - decision_log.json
    - agent_state.json
    - memory_records.json
    - chat_memory_snapshot.json
    - chat_memory.md
  memory/
    - SNAPSHOT.md   (agregado MEMORIA/BLOQUEO/SIGUIENTE de todos los chats)

Uso:
    python tools/sync_chat_memory.py                     # chat activo de hoy
    python tools/sync_chat_memory.py --chat chats/chat_2026-04-18.md
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))

from multiagents.chat_memory import (  # noqa: E402
    build_chat_memory,
    build_project_memory_entries,
    render_chat_memory_markdown,
    write_chat_memory_artifacts,
    write_project_memory_snapshot,
)


def sync(chat_path: str | None = None) -> str:
    snapshot = build_chat_memory(chat_path=chat_path)
    paths = write_chat_memory_artifacts(snapshot)
    entries = build_project_memory_entries()
    project_snapshot = write_project_memory_snapshot(entries)
    return (
        f"{render_chat_memory_markdown(snapshot)}\n"
        f"Artifacts:\n"
        f"- {paths['markdown']}\n"
        f"- {paths['snapshot']}\n"
        f"- {paths['conversation']}\n"
        f"- {paths['decisions']}\n"
        f"- {paths['agent_state']}\n"
        f"- {paths['memory_records']}\n"
        f"- {project_snapshot} (proyecto, agregado de MEMORIA/BLOQUEO/SIGUIENTE)"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--chat", default=None, help="Ruta al chat (por defecto chats/chat_<hoy>.md)")
    args = parser.parse_args()
    print(sync(args.chat))
    return 0


if __name__ == "__main__":
    sys.exit(main())
