"""
Registro de roles Scrum y agentes del sistema multiagente.

Template generico del tool-kit:
  - SCRUM_ROLES viene poblado con los tres roles canonicos (Scrum).
  - DOMAIN_AGENTS arranca vacio; el proyecto destino anade los suyos.
  - OPERATION_AGENTS incluye dos agentes transversales minimos (triage y reporting)
    porque `planner.py` los necesita como pilares del sprint.
  - COORDINATION_AGENTS incluye un orquestador generico.

Personalizacion: este fichero esta pensado para editarse. Cambia/anade
AgentSpec segun los sistemas y operaciones que tu proyecto maneje.
"""

from __future__ import annotations

from multiagents.models import AgentCapability, AgentSpec, ScrumRole


SCRUM_ROLES: list[ScrumRole] = [
    ScrumRole(
        name="Product Owner",
        mission="Mantener la vision del sprint, priorizar backlog y validar valor de negocio.",
        owned_artifacts=["Product Goal", "Product Backlog", "Sprint Goal"],
    ),
    ScrumRole(
        name="Scrum Master",
        mission="Facilitar el flujo del sprint, coordinar dependencias y eliminar bloqueos.",
        owned_artifacts=["Sprint Plan", "Daily Sync", "Retrospective"],
    ),
    ScrumRole(
        name="Developer",
        mission="Entregar incrementos verificables mediante cambios, sincronizacion o entrega.",
        owned_artifacts=["Increment", "Task Board", "Definition of Done"],
    ),
]


# --- AGENTES DE DOMINIO ---
# Rellena con los agentes especificos de tu proyecto. Ejemplo comentado:
#
# DOMAIN_AGENTS: list[AgentSpec] = [
#     AgentSpec(
#         key="my_domain_agent",
#         name="Mi Agente de Dominio",
#         kind="domain",
#         scope="Qué cubre",
#         owned_systems=["Sistema1", "Sistema2"],
#         owned_operations=["capture", "query", "sync"],
#         responsibilities=["Responsabilidad 1", "Responsabilidad 2"],
#         interfaces=["agents/my_agent.py"],
#         cli_entrypoint="python agents/my_agent.py",
#         capabilities=[
#             AgentCapability("op1", "Descripcion breve"),
#         ],
#     ),
# ]
DOMAIN_AGENTS: list[AgentSpec] = []


# --- AGENTES DE OPERACION (transversales) ---
# Dos agentes minimos requeridos por el planner. No los borres; personaliza si quieres.
OPERATION_AGENTS: list[AgentSpec] = [
    AgentSpec(
        key="intake_triage_agent",
        name="Intake & Triage Agent",
        kind="operation",
        scope="Clasificacion de solicitudes y derivacion al dominio correcto",
        owned_systems=[],
        owned_operations=["triage", "routing"],
        responsibilities=[
            "Analizar la intencion de la solicitud",
            "Asignar agentes de dominio y dependencias",
        ],
        interfaces=["multiagents/planner.py"],
    ),
    AgentSpec(
        key="reporting_retro_agent",
        name="Reporting & Retro Agent",
        kind="operation",
        scope="Artefactos Scrum, seguimiento y retrospectiva",
        owned_systems=[],
        owned_operations=["report", "inspect", "retro"],
        responsibilities=[
            "Generar backlog, sprint plan y resumenes",
            "Documentar retrospectivas y acciones de mejora",
        ],
        interfaces=["multiagents/artifacts.py"],
    ),
]


# --- AGENTE DE COORDINACION ---
COORDINATION_AGENTS: list[AgentSpec] = [
    AgentSpec(
        key="scrum_master_orchestrator",
        name="Scrum Master Orchestrator",
        kind="coordination",
        scope="Orquestacion global del sistema multiagente",
        owned_systems=[],
        owned_operations=["plan", "coordinate", "sprint"],
        responsibilities=[
            "Construir squads por objetivo",
            "Secuenciar trabajo por sprints",
            "Asignar agentes y definir entregables",
        ],
        interfaces=["tools/sprint.py"],
        cli_entrypoint="python tools/sprint.py",
    ),
]


ALL_AGENTS: list[AgentSpec] = DOMAIN_AGENTS + OPERATION_AGENTS + COORDINATION_AGENTS


def get_agent(key: str) -> AgentSpec:
    for agent in ALL_AGENTS:
        if agent.key == key:
            return agent
    raise KeyError(f"Agent not found: {key}")
