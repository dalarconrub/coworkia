"""
Generador de SprintPlan a partir de un objetivo en lenguaje natural.

Logica:
  1. `infer_systems(goal)` extrae sistemas relevantes por palabras clave.
  2. `infer_operations(goal)` extrae operaciones relevantes por palabras clave.
  3. `select_domain_agents` + `select_operation_agents` construyen el squad.
  4. `build_backlog` + `build_tasks` producen backlog y task board iniciales.
  5. `plan_sprint` envuelve todo en un SprintPlan con fechas, roles y eventos.

Personalizacion: edita `SYSTEM_KEYWORDS`, `OPERATION_KEYWORDS` y
`_build_task_commands()` para cablear los sistemas y tools de tu proyecto.
Sin personalizar, el planner produce sprints validos pero minimos (solo backlog
generico + agentes transversales).
"""

from __future__ import annotations

from datetime import date, timedelta

from multiagents.models import BacklogItem, SprintPlan, SprintTask, TaskCommand
from multiagents.registry import (
    COORDINATION_AGENTS,
    DOMAIN_AGENTS,
    OPERATION_AGENTS,
    SCRUM_ROLES,
)


# --- Palabras clave que disparan inferencia de sistemas / operaciones ---
# Rellena con los sistemas de tu proyecto. Ejemplo:
#
#   SYSTEM_KEYWORDS = {
#       "Database":  ["db", "database", "sql", "postgres"],
#       "API":       ["api", "endpoint", "rest"],
#   }
SYSTEM_KEYWORDS: dict[str, list[str]] = {}

# Operaciones genericas. Ampliar segun vocabulario del proyecto.
OPERATION_KEYWORDS: dict[str, list[str]] = {
    "capture": ["crear", "capturar", "alta", "anadir", "agregar"],
    "query":   ["listar", "consultar", "ver", "buscar", "estado"],
    "import":  ["importar"],
    "sync":    ["sincronizar", "actualizar"],
    "catalog": ["catalogar", "clasificar", "curar"],
    "backup":  ["backup", "exportar", "respaldo"],
    "plan":    ["plan", "sprint", "backlog", "scrum", "roadmap"],
}


def infer_systems(goal: str) -> list[str]:
    goal_lower = goal.lower()
    systems: list[str] = []
    for system, keywords in SYSTEM_KEYWORDS.items():
        if any(keyword in goal_lower for keyword in keywords):
            systems.append(system)
    # Fallback: si el proyecto no ha definido sistemas, devolver todos los declarados
    # por los agentes de dominio registrados. Si no hay agentes, lista vacia.
    if systems:
        return systems
    all_systems: list[str] = []
    for agent in DOMAIN_AGENTS:
        for system in agent.owned_systems:
            if system not in all_systems:
                all_systems.append(system)
    return all_systems


def infer_operations(goal: str) -> list[str]:
    goal_lower = goal.lower()
    operations: list[str] = []
    for operation, keywords in OPERATION_KEYWORDS.items():
        if any(keyword in goal_lower for keyword in keywords):
            operations.append(operation)
    return operations or ["plan", "query"]


def select_domain_agents(systems: list[str]) -> list:
    selected = []
    for agent in DOMAIN_AGENTS:
        if any(system in agent.owned_systems for system in systems):
            selected.append(agent)
    return selected


def select_operation_agents(operations: list[str]) -> list:
    selected = []
    for agent in OPERATION_AGENTS:
        if any(operation in agent.owned_operations for operation in operations):
            selected.append(agent)
    # Asegurar intake y reporting siempre presentes.
    intake = next((a for a in OPERATION_AGENTS if a.key == "intake_triage_agent"), None)
    reporting = next((a for a in OPERATION_AGENTS if a.key == "reporting_retro_agent"), None)
    if intake and not any(a.key == "intake_triage_agent" for a in selected):
        selected.insert(0, intake)
    if reporting and not any(a.key == "reporting_retro_agent" for a in selected):
        selected.append(reporting)
    return selected


def build_backlog(goal: str, systems: list[str], operations: list[str]) -> list[BacklogItem]:
    items: list[BacklogItem] = [
        BacklogItem(
            key="PB-001",
            title="Definir objetivo y criterios de aceptacion",
            description="Traducir la peticion a backlog operativo y Definition of Done.",
            systems=systems,
            operations=["plan"],
            acceptance_criteria=[
                "Existe sprint goal explicito",
                "Cada sistema afectado tiene dueno",
                "Cada resultado tiene criterio verificable",
            ],
            priority="high",
            estimate_points=3,
        ),
        BacklogItem(
            key="PB-002",
            title="Disenar squad multiagente por dominio y operacion",
            description="Asignar agentes especializados por sistema y por tipo de trabajo.",
            systems=systems,
            operations=["plan"],
            acceptance_criteria=[
                "Hay un agente de dominio por sistema implicado",
                "Hay agentes transversales para triage y reporting",
                "Se documentan dependencias entre agentes",
            ],
            priority="high",
            estimate_points=5,
        ),
        BacklogItem(
            key="PB-003",
            title="Preparar incremento del sprint",
            description="Convertir el objetivo en entregables ejecutables sobre el repo actual.",
            systems=systems,
            operations=operations,
            acceptance_criteria=[
                "Cada entregable se puede mapear a un archivo o comando",
                "Cada cambio tiene owner agente",
                "Se puede inspeccionar el incremento al final del sprint",
            ],
            priority="high",
            estimate_points=8,
        ),
    ]

    if any(op in operations for op in ("sync", "import", "backup")):
        items.append(
            BacklogItem(
                key="PB-004",
                title="Orquestar flujo de importacion y sincronizacion",
                description="Secuenciar operaciones entre sistemas externos y el catalogo interno.",
                systems=systems,
                operations=[op for op in operations if op in {"import", "sync", "backup"}],
                acceptance_criteria=[
                    "Las dependencias estan ordenadas",
                    "Los pasos tienen artefacto de salida",
                    "Los riesgos de fallo externo estan anotados",
                ],
                priority="medium",
                estimate_points=5,
            )
        )

    if "catalog" in operations or "query" in operations:
        items.append(
            BacklogItem(
                key="PB-005",
                title="Definir calidad de clasificacion y revision",
                description="Normalizar estados, etiquetas y propiedades para resultados consistentes.",
                systems=systems,
                operations=[op for op in operations if op in {"catalog", "query"}],
                acceptance_criteria=[
                    "Existe criterio de consistencia semantica",
                    "Se identifican taxonomias criticas",
                    "Hay revision final del incremento",
                ],
                priority="medium",
                estimate_points=3,
            )
        )

    return items


def _build_task_commands(agent_key: str, systems: list[str], operations: list[str]) -> list[TaskCommand]:
    """
    Cablea comandos concretos (scripts del repo) a tareas del sprint segun el
    agente propietario y las operaciones inferidas.

    Por defecto el kit NO cablea ningun comando: cada proyecto decide que
    scripts corresponden a que agente. Sobrescribe esta funcion anadiendo
    `TaskCommand(label=..., script_path=..., args=..., accepts_limit=...)`.

    Ejemplo:
        if agent_key == "my_sync_agent" and "sync" in operations:
            return [
                TaskCommand(
                    label="Sync remote",
                    script_path="tools/my_sync.py",
                    accepts_limit=True,
                )
            ]
    """
    return []


def build_tasks(
    goal: str,
    squad_agents: list,
    backlog: list[BacklogItem],
    systems: list[str],
    operations: list[str],
) -> list[SprintTask]:
    coordination_agent = COORDINATION_AGENTS[0] if COORDINATION_AGENTS else None
    tasks: list[SprintTask] = []

    if coordination_agent is not None:
        tasks.append(
            SprintTask(
                key="ST-001",
                title="Triage de objetivo y composicion del squad",
                owner_agent=coordination_agent.key,
                scrum_role="Scrum Master",
                depends_on=[],
                deliverable="Sprint Goal, squad matrix y secuencia inicial",
            )
        )

    domain_agents = [agent for agent in squad_agents if agent.kind == "domain"]
    operation_agents = [agent for agent in squad_agents if agent.kind == "operation"]

    task_index = len(tasks) + 1
    for agent in domain_agents:
        tasks.append(
            SprintTask(
                key=f"ST-{task_index:03d}",
                title=f"Preparar incremento en {agent.scope}",
                owner_agent=agent.key,
                scrum_role="Developer",
                depends_on=["ST-001"] if coordination_agent else [],
                deliverable=f"Entregable verificable en {', '.join(agent.interfaces) or agent.name}",
                commands=_build_task_commands(agent.key, systems, operations),
            )
        )
        task_index += 1

    for agent in operation_agents:
        if agent.key in {"intake_triage_agent", "reporting_retro_agent"}:
            continue
        tasks.append(
            SprintTask(
                key=f"ST-{task_index:03d}",
                title=f"Control transversal: {agent.name}",
                owner_agent=agent.key,
                scrum_role="Developer",
                depends_on=["ST-001"] if coordination_agent else [],
                deliverable=f"Criterios y soporte transversal para {agent.scope.lower()}",
                commands=_build_task_commands(agent.key, systems, operations),
            )
        )
        task_index += 1

    tasks.append(
        SprintTask(
            key=f"ST-{task_index:03d}",
            title="Cierre del sprint y retrospectiva",
            owner_agent="reporting_retro_agent",
            scrum_role="Scrum Master",
            depends_on=[task.key for task in tasks],
            deliverable="Sprint Review, metricas y acciones de mejora",
        )
    )

    return tasks


def plan_sprint(
    goal: str,
    sprint_name: str = "Sprint 1",
    start_date: date | None = None,
    duration_days: int = 14,
) -> SprintPlan:
    sprint_start = start_date or date.today()
    sprint_end = sprint_start + timedelta(days=duration_days - 1)
    systems = infer_systems(goal)
    operations = infer_operations(goal)

    coordination = list(COORDINATION_AGENTS)
    squad_agents = coordination + select_operation_agents(operations) + select_domain_agents(systems)

    seen = set()
    deduped_agents = []
    for agent in squad_agents:
        if agent.key not in seen:
            deduped_agents.append(agent)
            seen.add(agent.key)

    backlog = build_backlog(goal, systems, operations)
    tasks = build_tasks(goal, deduped_agents, backlog, systems, operations)

    events = [
        "Sprint Planning",
        "Daily Scrum",
        "Backlog Refinement",
        "Sprint Review",
        "Sprint Retrospective",
    ]
    artifacts = [
        "Product Goal",
        "Sprint Goal",
        "Sprint Backlog",
        "Increment",
        "Definition of Done",
    ]

    return SprintPlan(
        sprint_name=sprint_name,
        objective=goal,
        start_date=sprint_start,
        end_date=sprint_end,
        status="planned",
        scrum_roles=SCRUM_ROLES,
        squad_agents=deduped_agents,
        backlog=backlog,
        tasks=tasks,
        events=events,
        artifacts=artifacts,
    )
