# Agent Chat — {{DATE}}

_Fuente de verdad compartida del día. Todos los agentes leen este hilo completo antes de responder. Append-only._

## Participantes

- **Director** (rol fijo) — persona que coordina el trabajo. Puede entrar desde cualquier interfaz en cualquier momento.
- **Agentes IA raíz** intercambiables: por defecto `Claude`, `Copilot`, `Codex`. Cualquiera puede asumir cualquier función cuando se le solicita.
- **Subagentes** (opcional): variantes especializadas con notación `Root/Sub` (p. ej. `Claude/KIT`, `Codex/INX`). Heredan el protocolo de su raíz y se ciñen al foco declarado en `memory/ROSTER.md`.

> Personaliza las raíces editando `ROOT_AGENTS` en `multiagents/chat_memory.py` y `tools/devlog.py` (deben coincidir) y actualiza las referencias en `.claude/multiagent.md`, `CLAUDE.md`, `AGENTS.md` y `.github/copilot-instructions.md` si procede.

## Funciones asignables (cualquier agente, a petición)

- orquestación, síntesis, integración en IDE, visión de conjunto
- análisis profundo, razonamiento lógico, revisión crítica, teoría
- generación de código, refactoring, tests, implementación técnica

## Formato de mensajes

```
**Director [@Destinatario]:** mensaje
**Agente:** mensaje | propuesta | voto | evaluación
```

`Destinatario` puede ser una raíz (`Claude`/`Copilot`/`Codex`) o un subagente (`Root/Sub`, p. ej. `Claude/KIT`). Un subagente firma con su nombre completo (`**Claude/KIT:**`).

## Modos de decisión

| Símbolo            | Modo        | Cuándo usarlo                                |
| ------------------ | ----------- | -------------------------------------------- |
| 🗳️ VOTO #N        | Votación    | Decisión binaria rápida, mayoría simple      |
| 🔍 EVALUACIÓN #N   | Evaluación  | Comparar alternativas desde cada especialidad |
| 🎯 ESPECIALIDAD    | Delegación  | Dominio inequívoco — solo el director lo asigna |
| 💡 CREATIVIDAD #N  | Brainstorm  | Sin restricciones, enfoque fresco            |

## Marcadores canónicos

- `MEMORIA:` hecho o acuerdo duradero
- `BLOQUEO:` impedimento concreto
- `SIGUIENTE:` siguiente acción u owner
- `✅ CERRADO #N:` decisión finalizada

## Estado actual

- Decisiones abiertas: ninguna
- Última acción: inicio de sesión {{DATE}}

---
