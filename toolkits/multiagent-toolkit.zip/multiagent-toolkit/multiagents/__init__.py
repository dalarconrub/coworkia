"""Infraestructura base para el sistema multiagente (tool-kit portable)."""
