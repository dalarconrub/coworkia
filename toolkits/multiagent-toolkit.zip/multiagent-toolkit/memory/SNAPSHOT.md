# Project Memory Snapshot

_Stub. Se autogenera con `python tools/session.py close` (o `python tools/sync_chat_memory.py`) tras acumular `MEMORIA:` / `BLOQUEO:` / `SIGUIENTE:` en los chats del directorio `chats/`._

## MEMORIA (acuerdos duraderos)

- Ninguno.

## BLOQUEO (impedimentos)

- Ninguno.

## SIGUIENTE (handoffs pendientes)

- Ninguno.
