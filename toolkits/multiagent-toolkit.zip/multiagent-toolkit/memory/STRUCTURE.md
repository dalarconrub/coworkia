# STRUCTURE — {{NOMBRE DEL PROYECTO}}

> Mapa de carpetas y lógica de organización. **Documento híbrido**:
> - Secciones narrativas: curadas a mano (qué vive en cada carpeta y por qué).
> - Bloque TREE al final: regenerado por `python tools/snapshot_structure.py`.
>
> Regla: si añades o renombras una carpeta top-level, actualiza la narrativa y regenera el TREE en el mismo commit. Deja entrada `[DOCS]` en el devlog.

## Principio de organización

<!-- TODO: describe el principio que gobierna la disposición de carpetas en
     tu proyecto. Ejemplo:

     - Lo vivo (hilos, logs, memoria operativa) → `chats/`, `devlog/`, `artifacts/`.
     - Lo curado (identidad, propósito, estructura) → `memory/`, raíz.
     - Lo ejecutable (lógica del sistema) → `agents/`, `tools/`, `apps/`.
     - La documentación de uso → `docs/`.
-->

## Carpetas top-level

### `chats/` — hilo compartido diario
Un fichero por día (`chat_YYYY-MM-DD.md`). Append-only, UTF-8 estricto. Fuente de verdad de la conversación multiagente. Generado/resuelto por `tools/init_chat.py`.

### `devlog/` — log feature-level append-only
`DEVLOG.md` narrativo con entradas por hito (no por commit). Escrito vía `tools/devlog.py`. Obligatorio para todo agente cuando cierra decisión, completa feature, marca bloqueo, etc. Ver `.claude/multiagent.md` sección "DevLog obligatorio".

### `memory/` — memoria curada del proyecto
MDs de alto nivel que definen al proyecto frente a cualquier agente nuevo:

- `PURPOSE.md` — qué es y qué hace (curado).
- `STRUCTURE.md` — este mapa (híbrido).
- `INDEX.md` — meta-índice de todos los recursos (curado, se actualiza cuando nace un recurso nuevo).
- `ROSTER.md` — directorio curado de subagentes (`Root/Sub`) activos y su foco. Se edita a mano cuando el director activa o retira un subagente; cada cambio deja entrada `[DOCS]` en el devlog. Opcional (crear cuando el proyecto tenga al menos uno).
- `SNAPSHOT.md` — agregado auto-generado de `MEMORIA/BLOQUEO/SIGUIENTE` de todos los chats (generado por `tools/sync_chat_memory.py`).

### `multiagents/` — infraestructura del protocolo IA y Scrum
- `chat_memory.py` — parser del chat y generador de memoria estructurada.
- `chat_template.md` — plantilla del chat diario.
- `models.py` — dataclasses del sprint (`SprintPlan`, `SprintTask`, `SprintRun`, `TaskExecution`, `AgentSpec`).
- `registry.py` — `SCRUM_ROLES` (3 roles canónicos) + `DOMAIN_AGENTS` / `OPERATION_AGENTS` / `COORDINATION_AGENTS`. **Edita aquí** para declarar los agentes de tu proyecto.
- `planner.py` — genera un `SprintPlan` desde un objetivo en lenguaje natural. Inferencia por `SYSTEM_KEYWORDS` y `OPERATION_KEYWORDS` — **personalizable**.
- `artifacts.py` — serialización/deserialización de sprint a markdown + json.

### `tools/` — scripts transversales
- `init_chat.py` — resolver chat del día + briefing al arrancar.
- `devlog.py` — append y view sobre `DEVLOG.md`.
- `sync_chat_memory.py` — parsear chat → artifacts + SNAPSHOT.md.
- `sprint.py` — planificar, guardar, listar y consultar sprints.
- `snapshot_structure.py` — regenerar el bloque TREE de este mismo fichero.
- `memory_check.py` — validar integridad de `memory/`.
- `timeline.py` — agregar chat + devlog + sprints por fecha en `artifacts/daily/`.
- `fix_chat_mojibake.py` — reparar UTF-8 roto en chats.

### `artifacts/` — salidas operativas (regenerables)
- `artifacts/multiagent/` — memoria multiagente derivada. Regenerable con `python tools/sync_chat_memory.py`.
- `artifacts/sprints/` — planes y runtime de sprints (`<slug>.md` + `<slug>.json`). Generado por `python tools/sprint.py plan ... --save`.
- `artifacts/daily/` — vista temporal agregada. Regenerable con `python tools/timeline.py`.

<!-- TODO: añade aquí carpetas propias de tu proyecto.
     Ejemplo:

     ### `agents/` — <descripción>
     ### `apps/` — <descripción>
     ### `docs/` — <descripción>
     ### `data/` — <descripción>
-->

### `.claude/`, `.github/`
Protocolo y configuración de agentes:

- `.claude/multiagent.md` — protocolo compartido.
- `.github/copilot-instructions.md` — identidad/protocolo para Copilot.

### Raíz
- `README.md` — guía de uso del proyecto.
- `CLAUDE.md` — identidad y rol para Claude.
- `AGENTS.md` — identidad y rol para Codex.

## Reglas de crecimiento

1. **Nuevo componente top-level** → añade carpeta, actualiza la narrativa aquí, actualiza `memory/INDEX.md`, regenera `STRUCTURE.md` TREE.
2. **Nueva utilidad transversal** → en `tools/`.
3. **Nuevo tipo de artefacto derivado** → bajo `artifacts/<nombre>/`, documentar qué script lo regenera.

## Árbol actual

<!-- TREE:START -->

_Auto-generado por `tools/snapshot_structure.py` @ 2026-04-18T11:00Z. No editar a mano dentro de este bloque._

```
- .claude/
  - multiagent.md
- .github/
  - copilot-instructions.md
- artifacts/
  - daily/
  - multiagent/
  - sprints/
- chats/
- devlog/
  - DEVLOG.md
- memory/
  - INDEX.md
  - PURPOSE.md
  - ROSTER.md
  - SNAPSHOT.md
  - STRUCTURE.md
- multiagents/
  - __init__.py
  - artifacts.py
  - chat_memory.py
  - chat_template.md
  - models.py
  - planner.py
  - registry.py
- tools/
  - devlog.py
  - fix_chat_mojibake.py
  - init_chat.py
  - memory_check.py
  - session.py
  - snapshot_structure.py
  - sprint.py
  - sync_chat_memory.py
  - timeline.py
- AGENTS.md
- CLAUDE.md
- README.md
```

<!-- TREE:END -->
