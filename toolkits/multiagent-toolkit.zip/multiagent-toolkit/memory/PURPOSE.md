# PURPOSE — {{NOMBRE DEL PROYECTO}}

> Qué es este proyecto, para qué existe y cuáles son sus funcionalidades canónicas.
> Documento **curado a mano**. Actualizar cuando cambie la visión o los principios. Cualquier cambio deja entrada `[DOCS]` en el devlog.

## Qué es

<!-- TODO: 2-4 párrafos describiendo el proyecto.
     - ¿Qué problema resuelve?
     - ¿Quién lo usa?
     - ¿Qué dominios cubre?
     - ¿Qué integra con qué?
-->

## Funcionalidades principales

<!-- TODO: lista cada funcionalidad con un título corto y 2-4 bullets de detalle.
     Ejemplo:

     ### 1. <Funcionalidad>
     - Qué hace.
     - Cómo se invoca (CLI, GUI, API, trigger...).
     - Dónde vive en el repo.
-->

## Entidades / dominios canónicos

<!-- TODO: si tu proyecto tiene una división operativa clara, documéntala aquí.
     Ejemplo:

     | Código | Sistema | Rol operativo | Módulo responsable |
     | ------ | ------- | ------------- | ------------------ |
     | ...    | ...     | ...           | ...                |
-->

## Roles y agentes IA

- **Director** (rol fijo) — única autoridad para delegar `🎯 ESPECIALIDAD` y cerrar decisiones definitivas.
- **Claude** — análisis profundo, revisión crítica, evaluación de alternativas.
- **Copilot** — orquestación, síntesis, integración en VS Code.
- **Codex** — generación de código, refactoring, tests, implementación técnica.

Los roles son intercambiables por petición explícita del director, pero cada agente mantiene su identidad por defecto.

## Principios no negociables

<!-- Lista curada. Ejemplos mínimos ya incluidos por el kit; añade los de tu proyecto. -->

1. **Append-only en hilos compartidos.** Nunca se reescribe pasado (`chats/`, `devlog/`).
2. **UTF-8 estricto** en toda la capa de texto plano (chats, devlog, memory).
3. **El chat del día es la única fuente de conversación viva.** Todo lo demás es derivado.
4. **Toda decisión que altere operativa o implementación genera entrada en el devlog** el mismo turno.
5. **La memoria del proyecto (`memory/`) se lee antes que cualquier otra cosa** al arrancar un agente.
<!-- TODO: añade los invariantes propios de tu proyecto (p. ej. qué sistema es canónico, qué no se debe duplicar, etc.). -->

## Interfaces

<!-- TODO: lista canales de entrada al sistema.
     Ejemplos típicos:
     - CLI por agente: `python agents/<agente>.py <cmd>`
     - Apps: GUIs en `apps/`
     - Chat multiagente: `chats/chat_YYYY-MM-DD.md`
-->

## Fuera de alcance

<!-- TODO: declara explícitamente qué NO hace el proyecto, para evitar scope-creep. -->
