# INDEX — Memoria del proyecto {{NOMBRE DEL PROYECTO}}

> **Punto de entrada único para cualquier agente IA que arranque sesión.**
> Este fichero apunta a todos los recursos MD y artefactos que definen el proyecto a día de hoy.
> Se lee **antes que el chat del día**: es el mapa del territorio.

---

## 0. Identidad y propósito

| Recurso                                              | Qué contiene                                              |
| ---------------------------------------------------- | --------------------------------------------------------- |
| [memory/PURPOSE.md](PURPOSE.md)                      | Qué es el proyecto, visión, funcionalidades, principios no negociables |
| [memory/STRUCTURE.md](STRUCTURE.md)                  | Mapa de carpetas, lógica de organización, árbol auto-generado |
| [memory/SNAPSHOT.md](SNAPSHOT.md)                    | Agregado auto-generado de `MEMORIA:` / `BLOQUEO:` / `SIGUIENTE:` de todos los chats (regenerado por `tools/sync_chat_memory.py`) |
| [memory/ROSTER.md](ROSTER.md)                        | Directorio curado de subagentes (`Root/Sub`) activos y su foco (opcional; crear cuando haya al menos uno) |
| [README.md](../README.md)                            | Guía pública del proyecto                                 |

## 1. Protocolo de agentes (obligatorio leer según identidad)

| Agente     | Archivo principal                                                  | Rol                                   |
| ---------- | ------------------------------------------------------------------ | ------------------------------------- |
| Claude     | [CLAUDE.md](../CLAUDE.md)                                          | Análisis, revisión crítica            |
| Codex      | [AGENTS.md](../AGENTS.md)                                          | Implementación, código, tests         |
| Copilot    | [.github/copilot-instructions.md](../.github/copilot-instructions.md) | Orquestación, síntesis                |
| **Todos**  | [.claude/multiagent.md](../.claude/multiagent.md)                  | Protocolo compartido (append-only, formatos, marcadores, devlog) |

## 2. Conversación viva (hilo multiagente)

| Recurso                                          | Qué contiene                                     |
| ------------------------------------------------ | ------------------------------------------------ |
| [chats/](../chats/)                              | Histórico de chats diarios (`chat_YYYY-MM-DD.md`) |
| Chat activo del día                              | Resuelto por `python tools/init_chat.py`         |
| [multiagents/chat_template.md](../multiagents/chat_template.md) | Plantilla del chat diario              |

Regla: append-only, UTF-8 estricto. Leer completo antes de responder.

## 3. Decisiones y memoria multiagente (derivada)

Regenerable con `python tools/sync_chat_memory.py`. Las rutas en `artifacts/multiagent/` no existen hasta la primera ejecución:

| Recurso                                                     | Qué contiene                                     |
| ----------------------------------------------------------- | ------------------------------------------------ |
| `artifacts/multiagent/chat_memory.md`                       | Snapshot legible de la memoria multiagente       |
| `artifacts/multiagent/decision_log.json`                    | Log de decisiones (votos, evaluaciones, cierres) |
| `artifacts/multiagent/memory_records.json`                  | Hechos marcados con `MEMORIA:`                   |
| `artifacts/multiagent/agent_state.json`                     | Estado por agente (último mensaje, menciones)    |
| `artifacts/multiagent/conversation_records.jsonl`           | Log estructurado mensaje a mensaje               |

## 4. Desarrollos del proyecto (feature-level)

| Recurso                                   | Qué contiene                                  |
| ----------------------------------------- | --------------------------------------------- |
| [devlog/DEVLOG.md](../devlog/DEVLOG.md)   | Log append-only de desarrollos por hito       |
| `python tools/devlog.py view --limit 20`  | Últimas 20 entradas desde CLI                 |

Obligatorio: entrada tras `✅ CERRADO`, `MEMORIA:` operativa, feature completada, `BLOQUEO:` / `UNBLOCKED`, o `REVERT`.

## 5. Artefactos operativos

| Recurso                                             | Qué contiene                                     |
| --------------------------------------------------- | ------------------------------------------------ |
| [artifacts/sprints/](../artifacts/sprints/)         | Planes y runtime de sprints (`<slug>.md` + `<slug>.json`). Generado por `python tools/sprint.py plan ... --save` |
| [artifacts/daily/](../artifacts/daily/)             | Timeline agregada por día (regenerable con `python tools/timeline.py`) |

**Sprints:** `python tools/sprint.py {plan|status|list}`. El CLI usa `multiagents/planner.py` + `multiagents/registry.py` (configura aquí tus agentes) + `multiagents/artifacts.py` para persistir.

**Vista temporal:** `python tools/timeline.py [--date YYYY-MM-DD | --from ... --to ... | --days N]` agrega chat + devlog + **sprints activos** de un rango de fechas a `artifacts/daily/YYYY-MM-DD.md`. Solo lectura sobre las fuentes canónicas; no las modifica.

<!-- TODO: añade aquí referencias a los artefactos específicos de tu proyecto
     (p. ej. logs de sync, sprints, backups, etc.). -->

## 6. Documentación de usuario

<!-- TODO: rellena esta tabla con tus guías de `docs/` u otros destinos. -->

| Recurso | Qué contiene |
| ------- | ------------ |
|         |              |

## 7. Arranque y entorno

<!-- TODO: enumera aquí ficheros de arranque (README, launchers, .env.example,
     scripts de bootstrap, etc.). -->

---

## Orden de lectura recomendado al arrancar un agente

1. **[memory/INDEX.md](INDEX.md)** — este fichero.
2. **[memory/PURPOSE.md](PURPOSE.md)** — qué hace el proyecto.
3. **[memory/STRUCTURE.md](STRUCTURE.md)** — cómo está organizado.
4. **[memory/ROSTER.md](ROSTER.md)** — subagentes activos (si el proyecto usa alguno).
5. **Archivo de identidad** según agente: `CLAUDE.md` | `AGENTS.md` | `.github/copilot-instructions.md`.
6. **[.claude/multiagent.md](../.claude/multiagent.md)** — protocolo compartido.
7. **Chat del día** vía `python tools/init_chat.py` → leer completo.
8. **Últimas entradas del devlog** vía `python tools/devlog.py view --limit 20`.
9. Opcional si hay pregunta sobre decisiones previas: `artifacts/multiagent/chat_memory.md` (regenerado por `tools/sync_chat_memory.py`).

---

## Mantenimiento de este índice

- Se actualiza manualmente cuando:
  - Nace un recurso MD top-level nuevo.
  - Se crea un nuevo artefacto derivado.
  - Cambia la ruta o nombre de algo referenciado.
- Cada cambio a este fichero debe dejar entrada `[DOCS]` en el devlog.
- No se actualiza para ediciones internas de un recurso ya referenciado (esas viven en el devlog).
