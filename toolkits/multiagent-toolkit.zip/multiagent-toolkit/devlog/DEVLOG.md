# DevLog

> Registro append-only del desarrollo del proyecto a nivel **feature**, no a nivel commit.
> Fuente de verdad para narrar *qué se trabajó, por qué y con qué impacto*, complementando `git log` (código) y `chats/chat_YYYY-MM-DD.md` (conversación).

## Reglas

- **Append-only.** Nunca se edita ni borra una entrada previa. Si una entrada queda obsoleta, se añade otra que la corrija y se enlaza.
- **UTF-8 estricto.** En `Windows PowerShell 5.1`, todo acceso manual debe usar `-Encoding utf8`.
- **Orden cronológico inverso:** las entradas nuevas se añaden al final (cronológico natural); para consultar lo reciente, leer desde el final.
- **Una entrada por hito**, no por commit. Tipos válidos de `Estado`: `START`, `PROGRESS`, `BLOCKED`, `UNBLOCKED`, `DONE`, `REVERT`.
- **Tag `[AREA]` obligatorio** en el título. Áreas por defecto del kit: `MULTIAGENT`, `TOOLING`, `DOCS`, `INFRA`, `GENERAL`. Añade las específicas del proyecto editando `VALID_AREAS` en `tools/devlog.py`.
- **Escritura recomendada vía `python tools/devlog.py append ...`** (garantiza UTF-8, timestamp UTC y enlace al chat del día).
- **Archivado:** cuando un mes cierre o el fichero supere ~1500 líneas, mover histórico a `devlog/archive/DEVLOG-YYYY-MM.md` y dejar nota con el rango.

## Cuándo escribir una entrada (obligatorio para agentes)

Un agente **debe** añadir entrada al devlog cuando:

1. Cierra una decisión en el chat con `✅ CERRADO #N`.
2. Registra una `MEMORIA:` duradera que implique cambio operativo o de implementación.
3. Completa una tarea de código con cambios mergeados (hito de feature).
4. Registra un `BLOQUEO:` real que detiene trabajo en curso (`Estado: BLOCKED`) — y cuando se resuelva (`UNBLOCKED`).
5. Hace `REVERT` o rollback significativo.

No se escribe entrada para: commits de refactor menor, tipos de fix triviales, ediciones sin impacto en comportamiento.

## Esquema de entrada

```
## YYYY-MM-DDTHH:MMZ — Agente — [AREA] título breve
Estado: START | PROGRESS | BLOCKED | UNBLOCKED | DONE | REVERT
Chat: chats/chat_YYYY-MM-DD.md
Sprint: <nombre>             (opcional)
Commits: <sha1>, <sha2>      (opcional)
Refs: #issue, PR#, decision #N   (opcional)
Resumen: 1-3 frases. Qué cambió, por qué, impacto.
```

## Consulta rápida

```bash
python tools/devlog.py view                         # últimas 20 entradas
python tools/devlog.py view --area MULTIAGENT       # filtrar por área
python tools/devlog.py view --agent Claude --limit 5
python tools/devlog.py view --status BLOCKED        # bloqueos vigentes
```

## Entradas

<!-- append-only; nuevas entradas abajo -->

