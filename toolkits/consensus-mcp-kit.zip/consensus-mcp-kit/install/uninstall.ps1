# uninstall.ps1 — elimina el bloque consensus de los configs sin tocar el resto.
$ErrorActionPreference = 'Stop'

$CursorCfg = Join-Path $HOME '.cursor\mcp.json'
$ClaudeCfg = Join-Path $HOME '.claude.json'

function Remove-Consensus {
  param([string]$Path)
  if (-not (Test-Path $Path)) {
    Write-Host "[skip] $Path no existe"
    return
  }
  $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
  Copy-Item $Path "$Path.bak.$stamp" -Force
  Write-Host "[backup] $Path.bak.$stamp"
  $obj = Get-Content -Raw -Path $Path -Encoding UTF8 | ConvertFrom-Json -Depth 50
  if ($obj.mcpServers -and $obj.mcpServers.PSObject.Properties.Name -contains 'consensus') {
    $obj.mcpServers.PSObject.Properties.Remove('consensus')
    Write-Host "[removido] consensus de $Path"
  } else {
    Write-Host "[noop] consensus no estaba en $Path"
  }
  $json = $obj | ConvertTo-Json -Depth 50
  Set-Content -Path $Path -Value $json -Encoding utf8
}

Remove-Consensus -Path $CursorCfg
Remove-Consensus -Path $ClaudeCfg

Write-Host ""
Write-Host "Reinicia Cursor / VSCode para que el cambio surta efecto."
Write-Host "Si quieres también limpiar tokens guardados: powershell -ExecutionPolicy Bypass -File tools\reset_oauth.ps1"
