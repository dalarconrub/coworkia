#!/usr/bin/env bash
# install.sh — instala el MCP de Consensus en Cursor y/o Claude Code (VSCode)
# Uso: bash install/install.sh [--direct] [--port N] [--cursor-only] [--claude-only]
#
#   --direct        : usa HTTP directo (sin OAuth, modo anónimo top 3) en lugar de mcp-remote
#   --port N        : pasa --auth-server-port=N a mcp-remote (evita conflictos en 6761)
#   --cursor-only   : sólo configura ~/.cursor/mcp.json
#   --claude-only   : sólo configura ~/.claude.json
set -euo pipefail

KIT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CURSOR_CFG="$HOME/.cursor/mcp.json"
CLAUDE_CFG="$HOME/.claude.json"

DIRECT=0
PORT=""
DO_CURSOR=1
DO_CLAUDE=1

while [[ $# -gt 0 ]]; do
  case "$1" in
    --direct)       DIRECT=1; shift ;;
    --port)         PORT="$2"; shift 2 ;;
    --cursor-only)  DO_CLAUDE=0; shift ;;
    --claude-only)  DO_CURSOR=0; shift ;;
    *) echo "Argumento desconocido: $1" >&2; exit 2 ;;
  esac
done

ts() { date +%Y%m%d_%H%M%S; }

require_node() {
  if ! command -v node >/dev/null 2>&1; then
    echo "ERROR: node no está instalado. Instala Node 20 LTS antes de continuar." >&2
    return 1
  fi
  local ver="$(node --version | sed 's/^v//')"
  local major="${ver%%.*}"
  if [[ "$major" -lt 18 ]]; then
    echo "ERROR: Node $ver detectado. mcp-remote requiere Node >= 18." >&2
    return 1
  fi
  echo "[ok] Node $ver"
}

backup_if_exists() {
  local f="$1"
  if [[ -f "$f" ]]; then
    cp -p "$f" "${f}.bak.$(ts)"
    echo "[backup] ${f}.bak.$(ts)"
  fi
}

# Renderiza el bloque consensus según flags --direct / --port.
consensus_block_json() {
  if [[ "$DIRECT" -eq 1 ]]; then
    cat <<'EOF'
{ "type": "http", "url": "https://mcp.consensus.app/mcp" }
EOF
  else
    if [[ -n "$PORT" ]]; then
      printf '{ "command": "npx", "args": ["-y", "mcp-remote", "https://mcp.consensus.app/mcp", "--auth-server-port=%s"] }\n' "$PORT"
    else
      cat <<'EOF'
{ "command": "npx", "args": ["-y", "mcp-remote", "https://mcp.consensus.app/mcp"] }
EOF
    fi
  fi
}

install_cursor() {
  mkdir -p "$(dirname "$CURSOR_CFG")"
  backup_if_exists "$CURSOR_CFG"
  local block="$(consensus_block_json)"
  if [[ ! -f "$CURSOR_CFG" ]]; then
    printf '{\n  "mcpServers": {\n    "consensus": %s\n  }\n}\n' "$block" >"$CURSOR_CFG"
    echo "[creado] $CURSOR_CFG"
  else
    # merge con node (universal: cualquier instalación)
    node -e "
      const fs=require('fs'); const f='$CURSOR_CFG';
      const cur=JSON.parse(fs.readFileSync(f,'utf8'));
      cur.mcpServers = cur.mcpServers || {};
      cur.mcpServers.consensus = $block ;
      fs.writeFileSync(f, JSON.stringify(cur, null, 2)+'\n', 'utf8');
    "
    echo "[actualizado] $CURSOR_CFG"
  fi
}

install_claude_code() {
  mkdir -p "$(dirname "$CLAUDE_CFG")"
  backup_if_exists "$CLAUDE_CFG"
  local block="$(consensus_block_json)"
  if [[ ! -f "$CLAUDE_CFG" ]]; then
    printf '{\n  "mcpServers": {\n    "consensus": %s\n  }\n}\n' "$block" >"$CLAUDE_CFG"
    echo "[creado] $CLAUDE_CFG"
  else
    node -e "
      const fs=require('fs'); const f='$CLAUDE_CFG';
      const cur=JSON.parse(fs.readFileSync(f,'utf8'));
      cur.mcpServers = cur.mcpServers || {};
      cur.mcpServers.consensus = $block ;
      fs.writeFileSync(f, JSON.stringify(cur, null, 2)+'\n', 'utf8');
    "
    echo "[actualizado] $CLAUDE_CFG"
  fi
}

main() {
  echo "consensus-mcp-kit — install"
  echo "kit en: $KIT_ROOT"
  if [[ "$DIRECT" -eq 0 ]]; then
    require_node
  else
    echo "[info] modo --direct: no se requiere Node (mcp-remote no se usará)"
  fi
  [[ "$DO_CURSOR" -eq 1 ]] && install_cursor
  [[ "$DO_CLAUDE" -eq 1 ]] && install_claude_code
  echo
  echo "Siguiente:"
  echo "  1. Cierra completamente Cursor / VSCode (no recargar ventana)."
  echo "  2. Abre y dispara una búsqueda Consensus."
  if [[ "$DIRECT" -eq 0 ]]; then
    echo "  3. Se abrirá tu navegador en consensus.app/oauth/authorize. Login con cuenta Pro."
  fi
  echo "  4. bash tools/check_mcp.sh para verificar estado."
}

main "$@"
