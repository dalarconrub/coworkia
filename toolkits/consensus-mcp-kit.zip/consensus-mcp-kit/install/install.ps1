# install.ps1 — instala el MCP de Consensus en Cursor y/o Claude Code (VSCode) en Windows
# Uso:
#   powershell -ExecutionPolicy Bypass -File install\install.ps1
#   powershell -ExecutionPolicy Bypass -File install\install.ps1 -Direct
#   powershell -ExecutionPolicy Bypass -File install\install.ps1 -Port 6770
#   powershell -ExecutionPolicy Bypass -File install\install.ps1 -CursorOnly

[CmdletBinding()]
param(
  [switch]$Direct,
  [int]$Port = 0,
  [switch]$CursorOnly,
  [switch]$ClaudeOnly
)

$ErrorActionPreference = 'Stop'

$KitRoot = Split-Path -Parent $PSScriptRoot
$CursorCfg = Join-Path $HOME '.cursor\mcp.json'
$ClaudeCfg = Join-Path $HOME '.claude.json'

function Test-Node {
  if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    throw "node no está instalado. Instala Node 20 LTS: winget install OpenJS.NodeJS.LTS"
  }
  $verRaw = (& node --version).TrimStart('v')
  $major = [int]($verRaw.Split('.')[0])
  if ($major -lt 18) {
    throw "Node $verRaw detectado. mcp-remote requiere Node >= 18. Actualiza con: winget install OpenJS.NodeJS.LTS"
  }
  Write-Host "[ok] Node $verRaw"
}

function Backup-IfExists {
  param([string]$Path)
  if (Test-Path $Path) {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    Copy-Item $Path "$Path.bak.$stamp" -Force
    Write-Host "[backup] $Path.bak.$stamp"
  }
}

function Get-ConsensusBlock {
  if ($Direct) {
    return @{ type = 'http'; url = 'https://mcp.consensus.app/mcp' }
  }
  $args = @('-y', 'mcp-remote', 'https://mcp.consensus.app/mcp')
  if ($Port -gt 0) { $args += "--auth-server-port=$Port" }
  return @{ command = 'npx'; args = $args }
}

function Update-McpJson {
  param(
    [string]$Path,
    [string]$RootKey  # 'mcpServers' (Cursor / Claude Code)
  )
  $dir = Split-Path -Parent $Path
  if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  Backup-IfExists $Path

  $block = Get-ConsensusBlock
  if (Test-Path $Path) {
    $raw = Get-Content -Raw -Path $Path -Encoding UTF8
    $obj = $raw | ConvertFrom-Json -Depth 50
    if (-not $obj.PSObject.Properties.Name -contains $RootKey) {
      $obj | Add-Member -MemberType NoteProperty -Name $RootKey -Value (New-Object PSObject)
    }
    $servers = $obj.$RootKey
    if ($null -eq $servers) {
      $servers = New-Object PSObject
      $obj.$RootKey = $servers
    }
    if ($servers.PSObject.Properties.Name -contains 'consensus') {
      $servers.consensus = $block
    } else {
      $servers | Add-Member -MemberType NoteProperty -Name 'consensus' -Value $block
    }
    $json = $obj | ConvertTo-Json -Depth 50
    Set-Content -Path $Path -Value $json -Encoding utf8
    Write-Host "[actualizado] $Path"
  } else {
    $obj = New-Object PSObject
    $servers = New-Object PSObject
    $servers | Add-Member -MemberType NoteProperty -Name 'consensus' -Value $block
    $obj | Add-Member -MemberType NoteProperty -Name $RootKey -Value $servers
    $json = $obj | ConvertTo-Json -Depth 50
    Set-Content -Path $Path -Value $json -Encoding utf8
    Write-Host "[creado] $Path"
  }
}

Write-Host "consensus-mcp-kit — install"
Write-Host "kit en: $KitRoot"

if (-not $Direct) { Test-Node } else {
  Write-Host "[info] modo -Direct: no se requiere Node (mcp-remote no se usará)"
}

if (-not $ClaudeOnly) { Update-McpJson -Path $CursorCfg -RootKey 'mcpServers' }
if (-not $CursorOnly) { Update-McpJson -Path $ClaudeCfg -RootKey 'mcpServers' }

Write-Host ""
Write-Host "Siguiente:"
Write-Host "  1. Cierra completamente Cursor / VSCode (no recargar ventana)."
Write-Host "  2. Abre y dispara una búsqueda Consensus."
if (-not $Direct) {
  Write-Host "  3. Se abrirá tu navegador en consensus.app/oauth/authorize. Login con cuenta Pro."
}
Write-Host "  4. powershell -ExecutionPolicy Bypass -File tools\check_mcp.ps1 para verificar estado."
