#!/usr/bin/env bash
# uninstall.sh — elimina el bloque consensus de los configs sin tocar el resto.
# Hace backup previo. Restauración con cp del .bak más reciente.
set -euo pipefail

CURSOR_CFG="$HOME/.cursor/mcp.json"
CLAUDE_CFG="$HOME/.claude.json"

ts() { date +%Y%m%d_%H%M%S; }

remove_consensus() {
  local f="$1"
  if [[ ! -f "$f" ]]; then
    echo "[skip] $f no existe"
    return
  fi
  cp -p "$f" "${f}.bak.$(ts)"
  echo "[backup] ${f}.bak.$(ts)"
  node -e "
    const fs=require('fs'); const f='$f';
    const cur=JSON.parse(fs.readFileSync(f,'utf8'));
    if (cur.mcpServers && cur.mcpServers.consensus) {
      delete cur.mcpServers.consensus;
      console.log('[removido] consensus de '+f);
    } else {
      console.log('[noop] consensus no estaba en '+f);
    }
    fs.writeFileSync(f, JSON.stringify(cur, null, 2)+'\n', 'utf8');
  "
}

remove_consensus "$CURSOR_CFG"
remove_consensus "$CLAUDE_CFG"

echo
echo "Reinicia Cursor / VSCode para que el cambio surta efecto."
echo "Si quieres también limpiar tokens guardados: bash tools/reset_oauth.sh"
