#!/usr/bin/env bash
# check_mcp.sh — diagnóstico del estado del MCP de Consensus.
# Reporta: Node version, configs detectados, tokens guardados, estado del puerto OAuth.
set -uo pipefail

CURSOR_CFG="$HOME/.cursor/mcp.json"
CLAUDE_CFG="$HOME/.claude.json"
AUTH_DIR="$HOME/.mcp-auth"
OAUTH_PORT_DEFAULT="6761"

ok()    { printf "  \033[32m[ok]\033[0m %s\n" "$*"; }
warn()  { printf "  \033[33m[warn]\033[0m %s\n" "$*"; }
err()   { printf "  \033[31m[err]\033[0m %s\n" "$*"; }
info()  { printf "  [..] %s\n" "$*"; }

# Helper: comprueba un config y reporta si trae mcpServers.consensus
check_cfg() {
  local f="$1"
  if [[ ! -f "$f" ]]; then
    info "$f no existe"
    return
  fi
  local res
  res=$(node - "$f" <<'EOF' 2>&1 || true
const fs = require('fs');
const f = process.argv[2];
let raw;
try { raw = fs.readFileSync(f, 'utf8'); }
catch (e) { console.log('READ_ERR'); process.exit(0); }
let obj;
try { obj = JSON.parse(raw); }
catch (e) { console.log('JSON_ERR'); process.exit(0); }
if (obj.mcpServers && obj.mcpServers.consensus) {
  console.log('HAS_CONSENSUS');
} else {
  console.log('NO_CONSENSUS');
}
EOF
)
  case "$res" in
    HAS_CONSENSUS) ok "$f tiene mcpServers.consensus" ;;
    NO_CONSENSUS)  warn "$f existe pero NO tiene mcpServers.consensus" ;;
    JSON_ERR)      err "$f es JSON inválido" ;;
    READ_ERR)      err "$f ilegible" ;;
    *)             warn "$f estado desconocido ($res)" ;;
  esac
}

# Helper: parsea un tokens.json y muestra meta
describe_token() {
  local f="$1"
  node - "$f" <<'EOF' 2>/dev/null || echo "(error parseo)"
const fs = require('fs');
try {
  const t = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  console.log('scope=' + (t.scope||'?') + ' type=' + (t.token_type||'?') +
              ' expires_in=' + (t.expires_in||'?') +
              ' refresh=' + (t.refresh_token ? 'yes' : 'no'));
} catch (e) { console.log('(error parseo)'); }
EOF
}

echo "consensus-mcp-kit — check_mcp"
echo

echo "1) Node"
if command -v node >/dev/null 2>&1; then
  ver="$(node --version | sed 's/^v//')"
  major="${ver%%.*}"
  if [[ "$major" -ge 18 ]]; then
    ok "Node $ver"
  else
    err "Node $ver < 18 (mcp-remote no funcionará)"
  fi
else
  err "node no encontrado en PATH"
fi
echo

echo "2) Configs"
check_cfg "$CURSOR_CFG"
check_cfg "$CLAUDE_CFG"
echo

echo "3) Tokens OAuth (mcp-remote)"
if [[ -d "$AUTH_DIR" ]]; then
  shopt -s nullglob
  any=0
  for sub in "$AUTH_DIR"/mcp-remote-*/; do
    for tok in "$sub"*tokens.json; do
      any=1
      meta="$(describe_token "$tok")"
      ok "$(basename "$sub") :: $(basename "$tok") :: $meta"
    done
  done
  if [[ "$any" -eq 0 ]]; then
    warn "no hay tokens guardados — el OAuth aún no se ha completado"
  fi
else
  warn "$AUTH_DIR no existe — mcp-remote nunca se ha ejecutado o sus tokens no persistieron"
fi
echo

echo "4) Puerto OAuth callback ($OAUTH_PORT_DEFAULT)"
if command -v lsof >/dev/null 2>&1; then
  pids=$(lsof -t -iTCP:"$OAUTH_PORT_DEFAULT" -sTCP:LISTEN 2>/dev/null || true)
elif command -v ss >/dev/null 2>&1; then
  pids=$(ss -ltnp 2>/dev/null | awk -v p=":$OAUTH_PORT_DEFAULT" '$4 ~ p' | grep -oE 'pid=[0-9]+' | sed 's/pid=//' | sort -u || true)
elif command -v netstat >/dev/null 2>&1; then
  pids=$(netstat -ano 2>/dev/null | awk -v p=":$OAUTH_PORT_DEFAULT" '$0 ~ p && $0 ~ /LISTEN/ {print $NF}' | sort -u || true)
else
  pids=""
  warn "ninguna herramienta de inspección de puertos disponible (lsof/ss/netstat)"
fi
if [[ -n "${pids:-}" ]]; then
  ok "puerto $OAUTH_PORT_DEFAULT en uso por PID(s): $pids"
else
  info "puerto $OAUTH_PORT_DEFAULT libre"
fi
echo

echo "5) Procesos mcp-remote activos"
if command -v pgrep >/dev/null 2>&1; then
  pgrep_pids=$(pgrep -f "mcp-remote" 2>/dev/null || true)
  if [[ -n "$pgrep_pids" ]]; then
    ps -p $pgrep_pids -o pid,ppid,cmd 2>/dev/null | head -10
  else
    info "ningún mcp-remote corriendo"
  fi
elif command -v wmic >/dev/null 2>&1; then
  wmic process where "name='node.exe'" get ProcessId,CommandLine 2>/dev/null | grep -i mcp-remote | head -10 || info "ningún mcp-remote en node.exe"
fi
echo

echo "Resumen rápido:"
echo "  - Sin tokens y puerto libre: lanza el cliente y dispara una búsqueda → OAuth se inicia."
echo "  - Con tokens y puerto ocupado por mcp-remote: estado correcto en uso."
echo "  - Puerto ocupado por un node huérfano: bash tools/free_oauth_port.sh"
echo "  - Tokens presentes pero búsquedas en top 3: bash tools/reset_oauth.sh + relogin con cuenta Pro."
