# check_mcp.ps1 — diagnóstico del estado del MCP de Consensus en Windows.

$ErrorActionPreference = 'Continue'

$CursorCfg = Join-Path $HOME '.cursor\mcp.json'
$ClaudeCfg = Join-Path $HOME '.claude.json'
$AuthDir   = Join-Path $HOME '.mcp-auth'
$Port      = 6761

function Write-OK    { param($m) Write-Host "  [ok] $m"   -ForegroundColor Green }
function Write-Warn2 { param($m) Write-Host "  [warn] $m" -ForegroundColor Yellow }
function Write-Err2  { param($m) Write-Host "  [err] $m"  -ForegroundColor Red }
function Write-Info  { param($m) Write-Host "  [..] $m" }

Write-Host "consensus-mcp-kit — check_mcp"
Write-Host ""

Write-Host "1) Node"
if (Get-Command node -ErrorAction SilentlyContinue) {
  $ver = (& node --version).TrimStart('v')
  $major = [int]($ver.Split('.')[0])
  if ($major -ge 18) { Write-OK "Node $ver" } else { Write-Err2 "Node $ver < 18 (mcp-remote no funcionará)" }
} else {
  Write-Err2 "node no encontrado en PATH"
}
Write-Host ""

Write-Host "2) Configs"
foreach ($f in @($CursorCfg, $ClaudeCfg)) {
  if (Test-Path $f) {
    try {
      $obj = Get-Content -Raw -Path $f -Encoding UTF8 | ConvertFrom-Json -Depth 50
      if ($obj.mcpServers -and $obj.mcpServers.consensus) {
        Write-OK "$f tiene mcpServers.consensus"
      } else {
        Write-Warn2 "$f existe pero NO tiene mcpServers.consensus"
      }
    } catch {
      Write-Err2 "$f es JSON inválido"
    }
  } else {
    Write-Info "$f no existe"
  }
}
Write-Host ""

Write-Host "3) Tokens OAuth (mcp-remote)"
if (Test-Path $AuthDir) {
  $tokens = Get-ChildItem -Recurse -Path $AuthDir -Filter '*tokens.json' -ErrorAction SilentlyContinue
  if ($tokens) {
    foreach ($t in $tokens) {
      try {
        $td = Get-Content -Raw -Path $t.FullName -Encoding UTF8 | ConvertFrom-Json
        $hasRefresh = if ($td.refresh_token) { 'yes' } else { 'no' }
        Write-OK "$($t.Directory.Name) :: $($t.Name) :: scope=$($td.scope) type=$($td.token_type) expires_in=$($td.expires_in) refresh=$hasRefresh"
      } catch {
        Write-Warn2 "$($t.FullName) error de parseo"
      }
    }
  } else {
    Write-Warn2 "no hay tokens guardados — el OAuth aún no se ha completado"
  }
} else {
  Write-Warn2 "$AuthDir no existe — mcp-remote nunca se ha ejecutado o sus tokens no persistieron"
}
Write-Host ""

Write-Host "4) Puerto OAuth callback ($Port)"
$conns = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($conns) {
  $pids = ($conns | Select-Object -Expand OwningProcess -Unique) -join ','
  Write-OK "puerto $Port en uso por PID(s): $pids"
} else {
  Write-Info "puerto $Port libre"
}
Write-Host ""

Write-Host "5) Procesos node con mcp-remote"
$ms = Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue |
      Where-Object { $_.CommandLine -match 'mcp-remote' } |
      Select-Object ProcessId, ParentProcessId, CommandLine
if ($ms) {
  $ms | Format-Table -AutoSize | Out-String | Write-Host
} else {
  Write-Info "ningún mcp-remote corriendo"
}
Write-Host ""

Write-Host "Resumen rápido:"
Write-Host "  - Sin tokens y puerto libre: lanza el cliente y dispara una búsqueda → OAuth se inicia."
Write-Host "  - Con tokens y puerto ocupado por mcp-remote: estado correcto en uso."
Write-Host "  - Puerto ocupado por node huérfano: powershell -ExecutionPolicy Bypass -File tools\free_oauth_port.ps1"
Write-Host "  - Tokens presentes pero top 3 en búsquedas: powershell -ExecutionPolicy Bypass -File tools\reset_oauth.ps1 + relogin con Pro."
