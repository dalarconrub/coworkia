# free_oauth_port.ps1 — mata procesos node huérfanos que ocupan el puerto OAuth callback (default 6761).
# Uso:
#   powershell -ExecutionPolicy Bypass -File tools\free_oauth_port.ps1
#   powershell -ExecutionPolicy Bypass -File tools\free_oauth_port.ps1 -Port 6770

[CmdletBinding()]
param(
  [int]$Port = 6761
)

$ErrorActionPreference = 'Continue'

$conns = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if (-not $conns) {
  Write-Host "[ok] puerto $Port libre"
  exit 0
}

$pids = ($conns | Select-Object -Expand OwningProcess -Unique)
Write-Host "[info] procesos en ${Port}: $($pids -join ', ')"

foreach ($processId in $pids) {
  try {
    $proc = Get-Process -Id $processId -ErrorAction Stop
    if ($proc.ProcessName -match '^node') {
      Stop-Process -Id $processId -Force
      Write-Host "  [killed] $processId ($($proc.ProcessName))"
    } else {
      Write-Host "  [skip] $processId ($($proc.ProcessName)) — no es node, no toco"
    }
  } catch {
    Write-Host "  [warn] no pude inspeccionar/matar $processId : $_"
  }
}

Start-Sleep -Seconds 1
$conns2 = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if (-not $conns2) {
  Write-Host "[ok] puerto $Port libre tras limpieza"
} else {
  $pids2 = ($conns2 | Select-Object -Expand OwningProcess -Unique) -join ', '
  Write-Host "[err] aún ocupado por: $pids2"
  exit 1
}
