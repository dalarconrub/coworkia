#!/usr/bin/env bash
# free_oauth_port.sh — mata procesos node huérfanos que ocupan el puerto OAuth callback (default 6761).
# Uso: bash tools/free_oauth_port.sh [PORT]
set -uo pipefail

PORT="${1:-6761}"

list_pids() {
  if command -v lsof >/dev/null 2>&1; then
    lsof -t -iTCP:"$PORT" -sTCP:LISTEN 2>/dev/null
  elif command -v ss >/dev/null 2>&1; then
    ss -ltnp 2>/dev/null | awk -v p=":$PORT" '$4 ~ p' | grep -oE 'pid=[0-9]+' | sed 's/pid=//' | sort -u
  elif command -v netstat >/dev/null 2>&1; then
    netstat -ano 2>/dev/null | awk -v p=":$PORT" '$0 ~ p && $0 ~ /LISTEN/ {print $NF}' | sort -u
  else
    echo "ERROR: lsof/ss/netstat no disponibles" >&2
    return 2
  fi
}

pids="$(list_pids)"

if [[ -z "$pids" ]]; then
  echo "[ok] puerto $PORT libre"
  exit 0
fi

echo "[info] procesos en $PORT:"
echo "$pids" | sed 's/^/  /'

for pid in $pids; do
  # Confirma que es node antes de matar
  cmd=""
  if command -v ps >/dev/null 2>&1; then
    cmd=$(ps -p "$pid" -o comm= 2>/dev/null || true)
  fi
  if [[ -z "$cmd" || "$cmd" == "node" || "$cmd" == "node.exe" ]]; then
    if kill -9 "$pid" 2>/dev/null; then
      echo "  [killed] $pid"
    else
      echo "  [warn] no pude matar $pid (¿permisos?)"
    fi
  else
    echo "  [skip] $pid ($cmd) — no es node, no toco"
  fi
done

sleep 1
new="$(list_pids)"
if [[ -z "$new" ]]; then
  echo "[ok] puerto $PORT libre tras limpieza"
else
  echo "[err] aún ocupado por: $new"
  exit 1
fi
