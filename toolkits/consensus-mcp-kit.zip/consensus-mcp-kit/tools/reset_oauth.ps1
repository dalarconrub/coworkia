# reset_oauth.ps1 — purga tokens, client_info y code_verifier de mcp-remote.
$ErrorActionPreference = 'Continue'

$AuthDir = Join-Path $HOME '.mcp-auth'

if (-not (Test-Path $AuthDir)) {
  Write-Host "[skip] $AuthDir no existe — nada que limpiar."
  exit 0
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = "$AuthDir.bak.$stamp"
Copy-Item -Recurse -Force -Path $AuthDir -Destination $backup
Write-Host "[backup] $backup"

$removed = 0
$patterns = @('*tokens.json','*client_info.json','*code_verifier.txt','*lock.json')
$subs = Get-ChildItem -Path $AuthDir -Directory -Filter 'mcp-remote-*' -ErrorAction SilentlyContinue
foreach ($sub in $subs) {
  foreach ($pat in $patterns) {
    Get-ChildItem -Path $sub.FullName -Filter $pat -File -ErrorAction SilentlyContinue | ForEach-Object {
      Remove-Item -Force -Path $_.FullName
      Write-Host "[rm] $($_.FullName)"
      $removed++
    }
  }
}

if ($removed -eq 0) {
  Write-Host "[noop] no había ficheros OAuth de mcp-remote"
}

Write-Host ""
Write-Host "Siguiente:"
Write-Host "  1. Cierra completamente Cursor / VSCode."
Write-Host "  2. (opcional) cierra sesión en consensus.app desde el navegador para evitar cookie cacheada free."
Write-Host "  3. Abre el cliente y dispara una búsqueda → OAuth nuevo. Login con cuenta Pro."
