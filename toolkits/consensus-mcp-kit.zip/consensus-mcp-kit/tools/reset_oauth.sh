#!/usr/bin/env bash
# reset_oauth.sh — purga tokens, client_info y code_verifier de mcp-remote para Consensus.
# Tras esto, el siguiente arranque del cliente forzará nuevo OAuth.
set -uo pipefail

AUTH_DIR="$HOME/.mcp-auth"
ts() { date +%Y%m%d_%H%M%S; }

if [[ ! -d "$AUTH_DIR" ]]; then
  echo "[skip] $AUTH_DIR no existe — nada que limpiar."
  exit 0
fi

# Backup completo del directorio antes de borrar nada.
backup="$AUTH_DIR.bak.$(ts)"
cp -rp "$AUTH_DIR" "$backup"
echo "[backup] $backup"

shopt -s nullglob
removed=0
for sub in "$AUTH_DIR"/mcp-remote-*/; do
  for f in "$sub"*tokens.json "$sub"*client_info.json "$sub"*code_verifier.txt "$sub"*lock.json; do
    rm -f "$f" && { echo "[rm] $f"; removed=$((removed+1)); }
  done
done

if [[ "$removed" -eq 0 ]]; then
  echo "[noop] no había ficheros OAuth de mcp-remote"
fi

echo
echo "Siguiente:"
echo "  1. Cierra completamente Cursor / VSCode."
echo "  2. (opcional) cierra sesión en consensus.app desde el navegador para evitar cookie cacheada free."
echo "  3. Abre el cliente y dispara una búsqueda → OAuth nuevo. Login con cuenta Pro."
