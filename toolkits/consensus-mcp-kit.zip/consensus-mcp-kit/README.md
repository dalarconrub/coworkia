# consensus-mcp-kit — Configurar el MCP de Consensus (Cursor + VSCode/Claude Code)

Kit portable para conectar el **MCP oficial de Consensus** (`https://mcp.consensus.app/mcp`) en Cursor y en VSCode con Claude Code, evitando los problemas operativos habituales: planes free vs Pro, conflictos de puerto OAuth, dobles spawns de `mcp-remote`, conectores legacy de claude.ai con cuota agotada.

Sirve para cualquier proyecto. No depende de `memory/`, `devlog/`, ni de ningún otro toolkit.

## Qué resuelve

1. **Diferenciación de configs**: Cursor (panel MCP nativo) y Claude Code (CLI) usan archivos distintos. El kit genera ambos desde plantillas idénticas.
2. **Plan tier mismatch**: el conector legacy `claude.ai Consensus` tiene cuota mensual de 30 búsquedas independiente de tu suscripción Pro de consensus.app. El kit instala la conexión directa a `mcp.consensus.app` que sí respeta tu plan Pro tras OAuth.
3. **Conflictos de puerto OAuth (EADDRINUSE 6761)**: dos instancias de `mcp-remote` peleando por el callback. El kit incluye un comando para liberar el puerto y otro para purgar tokens corruptos.
4. **Diagnóstico**: un único script que revisa Node version, puerto, tokens guardados, configs y procesos huérfanos.

## Estructura

```
consensus-mcp-kit/
├── README.md                       <- este fichero
├── CHANGELOG.md
├── docs/
│   ├── BACKGROUND.md               <- por qué existen 3 variantes (legacy claude.ai, HTTP directo, mcp-remote)
│   └── TROUBLESHOOTING.md          <- catálogo de errores conocidos y solución
├── templates/
│   ├── README.md                   <- cuándo usar cada plantilla
│   ├── cursor-mcp.json             <- ~/.cursor/mcp.json (mcp-remote, recomendado)
│   ├── claude-code-mcp.json        <- snippet para ~/.claude.json (mcp-remote, recomendado)
│   ├── claude-code-mcp.direct.json <- snippet alternativo HTTP directo (menos fiable)
│   └── vscode-mcp.json             <- .vscode/mcp.json (extensiones MCP en VSCode)
├── install/
│   ├── install.sh                  <- instalador bash (Linux/macOS/Git Bash en Windows)
│   ├── install.ps1                 <- instalador PowerShell (Windows)
│   ├── uninstall.sh
│   └── uninstall.ps1
└── tools/
    ├── check_mcp.sh                <- diagnóstico estado del MCP
    ├── check_mcp.ps1
    ├── reset_oauth.sh              <- borra tokens y caché de mcp-remote
    ├── reset_oauth.ps1
    ├── free_oauth_port.sh          <- mata procesos huérfanos que ocupan el callback OAuth
    └── free_oauth_port.ps1
```

## Requisitos previos

- **Node.js ≥ 18** (recomendado v20 LTS o superior).
  - Verifica: `node --version`. Si tienes < 18, actualiza con `winget install OpenJS.NodeJS.LTS` (Windows), `brew install node@20` (macOS) o `nvm install 20`.
  - Razón: `mcp-remote` y sus dependencias (`open`, `undici`, `wsl-utils`) requieren Node 18 (algunas, Node 20.18+).
- **Cuenta en consensus.app** con plan Pro (opcional pero recomendado: 1.000 búsquedas/mes, top 20 resultados).
- **Cursor 0.42+** y/o **VSCode** con extensión Claude Code o cualquier cliente MCP compatible.

## Instalación

### bash (Linux/macOS/Git Bash)

```bash
cd /ruta/a/consensus-mcp-kit
bash install/install.sh
```

### PowerShell (Windows)

```powershell
cd \ruta\a\consensus-mcp-kit
powershell -ExecutionPolicy Bypass -File install\install.ps1
```

El instalador:
1. Detecta los clientes presentes (Cursor, VSCode con Claude Code).
2. Hace backup de los configs existentes (`~/.cursor/mcp.json.bak.YYYYMMDD_HHMMSS`, `~/.claude.json.bak.*`).
3. Inyecta el bloque `consensus` apuntando a `mcp-remote` (no destruye otras entradas `mcpServers`).
4. Recuerda los pasos siguientes (reiniciar el cliente y completar OAuth).

## Uso diario

Después de instalar:

1. **Cierra y reabre el cliente** (Cursor o VSCode). Recargar ventana NO basta — Node se invoca al arranque del proceso del cliente.
2. **Lanza una búsqueda** desde el chat (en el caso de Claude Code, una invocación al tool `mcp__consensus__search`). La primera vez:
   - `mcp-remote` registra un cliente OAuth dinámico contra `consensus.app`.
   - Abre tu navegador en `https://consensus.app/oauth/authorize?…&scope=search&redirect_uri=http://localhost:6761/oauth/callback`.
   - **Inicia sesión con la cuenta que tiene el plan Pro** (importante: si tu navegador tiene cookie de otra cuenta, ciérrala antes).
   - Tras autorizar, el navegador redirige a `localhost:6761/oauth/callback` y muestra "Authorization successful".
3. **Comprueba el plan** con una búsqueda de prueba: si la respuesta incluye "Found N papers, showing top 20" → Pro activo. Si dice "Found N papers, showing top 3" → estás en modo anónimo, ejecuta `tools/reset_oauth.*` y repite.

## Reglas operativas clave (invariantes)

1. **Una sola instancia de `mcp-remote` por cliente**. No dupliques `consensus` en `~/.cursor/mcp.json` y en otra config si ambas se cargan en el mismo proceso — chocarán por el puerto 6761.
2. **Los tokens caducan a las 4 horas** (`expires_in: 14400`). `mcp-remote` los renueva con el `refresh_token` automáticamente.
3. **El conector legacy "claude.ai Consensus"** (no este kit) tiene una cuota mensual de 30 búsquedas en plan free, independiente de tu Pro. Si te aparece y este kit, usas dos canales en paralelo.
4. **El plan se enlaza con el OAuth, no con el correo**. Si autorizas con cuenta sin Pro, recibes top 3 aunque tengas otra cuenta Pro abierta a la vez.
5. **Backups**: el instalador hace backup; el desinstalador restaura. Si editas a mano, mantén la convención `.bak.YYYYMMDD_HHMMSS`.

## Troubleshooting rápido

| Síntoma | Probable causa | Solución |
| --- | --- | --- |
| `EADDRINUSE 127.0.0.1:6761` | Otra instancia de `mcp-remote` ocupa el puerto | `tools/free_oauth_port.*` |
| "Found N papers, showing top 3" | OAuth quedó en modo anónimo o cuenta free | `tools/reset_oauth.*` + repetir login con Pro |
| `SyntaxError: ... node:fs/promises ... constants` | Node < 18 | Actualiza Node a 20 LTS |
| Cursor no detecta `consensus` | Recarga de ventana en lugar de reinicio completo | Cerrar Cursor (Quit) y reabrir |
| Login no abre navegador | mcp-remote falló silenciosamente al spawn | `tools/check_mcp.*` para diagnosticar |
| OAuth completa pero los tools no aparecen en una conversación abierta | El listado de tools de la conversación es estático | Abrir nueva conversación |

Detalle completo en [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md).

## Extender el kit

- **Añadir otro MCP** (Slack, Notion, lo que sea): copia `templates/cursor-mcp.json`, ajusta `command`/`url`, mete el bloque adicional en `mcpServers`.
- **Cambiar el puerto OAuth**: pasa `--auth-server-port=<N>` en `args` para evitar conflictos sistemáticos con otros mcp-remote.
- **Cambiar a HTTP directo** (sin OAuth): usa `templates/claude-code-mcp.direct.json`. Funciona en modo anónimo (top 3) sin login.

## Smoke-test

Tras instalar (en directorio virgen):

```bash
node --version                                        # debe ser >= 18
bash tools/check_mcp.sh                               # debería listar configs detectados, tokens, port libre
# (reiniciar cliente + completar OAuth)
bash tools/check_mcp.sh                               # ahora con tokens.json presentes y port ocupado por mcp-remote
```

Si los dos `check_mcp` reportan estados consistentes, el kit está operativo.

## Anti-patrones

- **No mezclar Pro + legacy claude.ai connector** sin saberlo. Si el conector legacy está activo, sus tools (`mcp__claude_ai_Consensus__*`) compiten en el listado con los tuyos (`mcp__consensus__*`); puedes acabar usando el equivocado y consumiendo cuota free.
- **No hard-codear API keys** en los configs. Consensus usa OAuth, no API key. Si ves un campo `Authorization: Bearer ...` lo más probable es que sea el token guardado en `~/.mcp-auth/`, **no** una key — no lo expongas.
- **No commitear `~/.cursor/mcp.json` ni `~/.claude.json`** del usuario al repo. Son configs personales con tokens potenciales.

## Origen

Extraído del proyecto `ja-linea-1-2026` siguiendo el playbook `playbooks/extract-portable-toolkit.md`. Cualquier mejora en el kit debe revisarse contra los configs activos del proyecto origen.
