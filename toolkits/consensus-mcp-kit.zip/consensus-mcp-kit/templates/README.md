# Plantillas — cuándo usar cada una

| Plantilla | Destino | Cuándo usarla |
| --- | --- | --- |
| `cursor-mcp.json` | `~/.cursor/mcp.json` | Cursor (Composer/Chat nativo) — recomendado por defecto |
| `claude-code-mcp.json` | bloque `mcpServers.consensus` dentro de `~/.claude.json` | Claude Code en VSCode/Cursor — recomendado |
| `claude-code-mcp.direct.json` | bloque `mcpServers.consensus` dentro de `~/.claude.json` | Sólo si OAuth falla repetidamente. Funciona en modo anónimo (top 3 resultados). No requiere Node ni `mcp-remote` |
| `vscode-mcp.json` | `<workspace>/.vscode/mcp.json` o ruta equivalente | Extensiones MCP en VSCode (Continue, Cline, Copilot Workspace) — depende de la extensión |

## Diferencias entre `cursor-mcp.json` y `claude-code-mcp.json`

- Cursor espera el JSON envuelto en `{ "mcpServers": { ... } }`.
- Claude Code espera el bloque dentro del objeto raíz de `~/.claude.json` bajo la clave `mcpServers`. El instalador inserta el bloque sin tocar el resto del archivo.

## Coexistencia con otros MCPs

Si ya tienes otros servidores MCP en `mcpServers` (por ejemplo `slack`, `notion`, `gmail`), **no los borres** — el instalador hace `merge`, no `replace`. Si editas a mano:

```jsonc
{
  "mcpServers": {
    "slack": { /* ... lo que tenías ... */ },
    "consensus": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "https://mcp.consensus.app/mcp"]
    }
  }
}
```

## Cambiar el puerto de callback OAuth

Si tienes varios `mcp-remote` activos y chocan en el puerto 6761, añade `--auth-server-port` al `args`:

```json
{
  "command": "npx",
  "args": ["-y", "mcp-remote", "https://mcp.consensus.app/mcp", "--auth-server-port=6770"]
}
```

Recuerda registrar el puerto distinto si reutilizas configs entre máquinas.
