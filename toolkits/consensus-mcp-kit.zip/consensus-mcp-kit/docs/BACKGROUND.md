# BACKGROUND — Por qué hay tantas variantes para conectar Consensus

Hay **tres formas** de invocar a Consensus desde un cliente IA. Conocerlas evita perder horas en autenticación que no termina de funcionar.

## 1. Conector legacy "claude.ai Consensus" (Anthropic)

Lo expone Anthropic dentro de Claude.ai como integración oficial. Aparece automáticamente en Claude Code (web, desktop, extensión VSCode/Cursor).

- **Tool name**: `mcp__claude_ai_Consensus__search`.
- **Cuota**: **30 búsquedas/mes en plan free** del lado de Anthropic, **independiente** de tu suscripción Pro de consensus.app. Si pagas Pro a consensus.app y usas este conector, sigues con 30/mes hasta que Anthropic enlace su backend con tu cuenta Pro (a fecha de hoy no existe ese enlace).
- **Top resultados**: 10 por búsqueda.
- **Activación**: viene activado por defecto si has hecho login con cuenta Anthropic. Se gestiona desde claude.ai → Connectors.

Usar este conector está bien para uso casual. Para uso intensivo o si tienes Pro, hay que ir a la conexión directa.

## 2. Conexión directa HTTP a `mcp.consensus.app/mcp`

El servidor MCP oficial de Consensus está en `https://mcp.consensus.app/mcp`.

- **Tool name**: `mcp__consensus__search` (depende de cómo nombres el server en tu config).
- **Cuota anónima**: 3 resultados/búsqueda, sin login. Limitado pero útil cuando OAuth falla.
- **Cuota Pro**: 1.000 búsquedas/mes, top 20 resultados, datos extendidos (citas, SJR, study type).
- **Cómo se autentica**: OAuth 2.0 con PKCE. El cliente MCP redirige al navegador → consensus.app/oauth/authorize → callback en localhost.

Variantes según cómo lo configures:

### 2a. HTTP directo (sin proxy)

```json
{ "type": "http", "url": "https://mcp.consensus.app/mcp" }
```

- Conecta directamente. **No dispara OAuth automáticamente** en Claude Code/Cursor → queda en modo anónimo (top 3).
- Útil sólo si no necesitas Pro y quieres una integración mínima.

### 2b. mcp-remote (recomendado)

```json
{ "command": "npx", "args": ["-y", "mcp-remote", "https://mcp.consensus.app/mcp"] }
```

- `mcp-remote` es un proxy local stdio→HTTP que **sí** maneja OAuth.
- Al detectar que el servidor pide auth, abre el navegador en la URL de autorización, escucha el callback en `localhost:6761`, intercambia el código por tokens y los persiste en `~/.mcp-auth/mcp-remote-<version>/<hash>_tokens.json`.
- Renueva el token con `refresh_token` cuando caduca (cada 4 horas).
- Requiere **Node ≥ 18** (sus deps `open`, `undici`, `wsl-utils` no funcionan en Node 16).

## 3. Convivencia entre conectores

Si tienes activos al mismo tiempo el conector legacy de claude.ai y la conexión directa:

- **Ambos tools aparecen** en el listado del agente: `mcp__claude_ai_Consensus__search` y `mcp__consensus__search`.
- El agente puede elegir cualquiera. Si elige el legacy y has agotado las 30 búsquedas, te dará error de cuota — aunque el otro funcione.
- Recomendación: **deshabilita el legacy** desde claude.ai → Connectors si vas a usar el directo. O al menos, dale instrucciones explícitas al agente de usar `mcp__consensus__*`.

## Tabla resumen

| Variante | Auth | Cuota | Top results | Node requerido | Uso recomendado |
| --- | --- | --- | --- | --- | --- |
| Legacy claude.ai | Anthropic OAuth | 30/mes | 10 | No | Uso ocasional |
| HTTP directo (`type: http`) | Ninguna | 3 por búsqueda anónimo | 3 | No | Backup cuando OAuth falla |
| mcp-remote | Consensus OAuth | Pro: 1.000/mes; Free: ? | Pro 20, Free 10 | ≥ 18 | Uso intensivo con Pro |

## Cómo se relaciona esto con `mcp.json`

| Cliente | Archivo | Estructura |
| --- | --- | --- |
| Cursor (Composer/Chat) | `~/.cursor/mcp.json` | `{ "mcpServers": { "consensus": {...} } }` |
| Claude Code (VSCode ext / CLI) | `~/.claude.json` | bloque dentro de la clave `mcpServers` del objeto raíz |
| VSCode + Continue | `~/.continue/config.json` | depende de la extensión |
| VSCode + extensión MCP nativa | `<workspace>/.vscode/mcp.json` | `{ "servers": { "consensus": {...} } }` |

Cada cliente lee su propio archivo. Configurar uno **no** afecta a los demás. Si cambias de cliente, replica la config.
