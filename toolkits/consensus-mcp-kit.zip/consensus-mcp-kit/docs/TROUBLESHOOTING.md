# TROUBLESHOOTING — consensus-mcp-kit

Catálogo de errores conocidos y solución. Ordenados por frecuencia.

## 1. `EADDRINUSE: address already in use 127.0.0.1:6761`

**Síntoma** (en log MCP del cliente):

```
Error: listen EADDRINUSE: address already in use 127.0.0.1:6761
    at Server.setupListenHandle ...
```

**Causa**: ya hay un proceso `node` ocupando el puerto que `mcp-remote` usa para el callback OAuth. Ocurre cuando:

- Hubo un reinicio "sucio" del cliente y dejó un `mcp-remote` huérfano.
- Tienes la misma conexión configurada en dos sitios (`~/.cursor/mcp.json` y `~/.claude.json`) y ambos clientes intentan spawnar mcp-remote a la vez.
- Le diste a "Restart MCP" varias veces seguidas en la UI.

**Solución rápida**:

```bash
bash tools/free_oauth_port.sh        # libera 6761
```

```powershell
.\tools\free_oauth_port.ps1
```

Después, en Cursor: Settings → MCP → click "Restart" en `consensus`. En Claude Code: nueva conversación.

**Solución definitiva (si choca repetidamente)**: añade `--auth-server-port=6770` (u otro puerto libre) al `args`:

```json
{
  "command": "npx",
  "args": ["-y", "mcp-remote", "https://mcp.consensus.app/mcp", "--auth-server-port=6770"]
}
```

Si tienes dos clientes consumiendo el mismo MCP, asígnales puertos distintos.

## 2. "Found N papers, showing top 3" (anonymous mode)

**Síntoma**: la búsqueda devuelve sólo 3 resultados y un mensaje del estilo:

> Create or connect a free Consensus account to return more than 3 results per search in Claude Code.

**Causa**: el flujo OAuth no completó, o se completó con cuenta sin Pro. El token guardado tiene `scope: search` pero la sesión se trata como anónima.

**Solución**:

1. Cierra sesión en consensus.app desde el navegador (con la cuenta no-Pro que pueda tener cookie cacheada).
2. Limpia el caché OAuth del kit:
   ```bash
   bash tools/reset_oauth.sh
   ```
   ```powershell
   .\tools\reset_oauth.ps1
   ```
3. Reinicia el cliente (Cursor/VSCode completamente, no recargar ventana).
4. Lanza una búsqueda. mcp-remote abrirá el navegador. **Inicia sesión con la cuenta exacta que tiene Pro**. Verifica antes en `consensus.app/account` que la cuenta tiene Pro activo.
5. Tras autorizar, `tools/check_mcp.*` debe mostrar `tokens.json` presente.

Si tras varios intentos sigues en top 3 con cuenta Pro válida, es bug del lado de consensus.app — abre ticket con el `client_info.json` (sin tokens) como prueba.

## 3. `SyntaxError: ... node:fs/promises ... constants`

**Síntoma**:

```
file:///.../mcp-remote/.../wsl-utils/index.js:2
import fs, {constants as fsConstants} from 'node:fs/promises';
            ^^^^^^^^^
SyntaxError: The requested module 'node:fs/promises' does not provide an export named 'constants'
```

**Causa**: Node < 18. El paquete `wsl-utils` (dependencia de `open` que usa `mcp-remote`) requiere Node 18+.

**Solución**: actualiza Node.

```powershell
winget install OpenJS.NodeJS.LTS    # Windows
```

```bash
brew install node@20                 # macOS
nvm install 20 && nvm use 20         # Linux/cualquiera con nvm
```

Verifica `node --version` ≥ 18 (recomendado 20 o 24). Cierra cliente IA y reabre.

## 4. Cursor no detecta `consensus` aunque el config existe

**Síntoma**: editas `~/.cursor/mcp.json`, recargas la ventana de Cursor, y en Settings → MCP no aparece el servidor.

**Causa**: Cursor lee `mcp.json` al **arrancar el proceso**, no al recargar ventana.

**Solución**: cierra Cursor por completo (icono de bandeja → Quit, no sólo cerrar ventana) y vuelve a abrir.

Verifica que el JSON es válido:

```bash
node -e "JSON.parse(require('fs').readFileSync(require('os').homedir()+'/.cursor/mcp.json','utf8'))"
```

Si error → revisa comas finales y comillas.

## 5. El botón "Sign in" no hace nada

**Síntoma**: en Cursor → Settings → MCP, click en `consensus` → "Sign in" → el botón se ilumina pero no abre nada.

**Causa**: el OAuth se delega al cliente MCP (mcp-remote). Si éste falla al spawn (Node antiguo, paquete corrupto), no hay browser que abrir.

**Solución**:

1. Abre los logs MCP de Cursor: `~/.config/Cursor/logs/<timestamp>/window<N>/exthost/anysphere.cursor-mcp/MCP user-consensus.log` (Linux) o equivalente Windows/macOS.
2. Busca errores recientes (`tail -40` del archivo). Suelen ser EADDRINUSE o SyntaxError (puntos 1 y 3 de este doc).
3. Aplica la solución correspondiente.

Si el log dice `Browser opened automatically.` pero no ves nada, comprueba bloqueadores de pop-ups o que tu navegador por defecto está accesible.

## 6. OAuth completa pero los tools no aparecen en la conversación abierta

**Síntoma**: ves `Authorization successful! You may close this window`, el token se guarda en `~/.mcp-auth/`, pero al pedirle al agente que use `mcp__consensus__search` dice que no existe.

**Causa**: el listado de tools de una conversación de Claude Code es estático — se fija al inicio. Añadir un MCP a mitad no actualiza el listado.

**Solución**: abre **una nueva conversación** Claude Code. La nueva sesión re-poll los servidores MCP y registrará los tools disponibles.

## 7. mcp-remote pide OAuth en cada arranque (no persiste el token)

**Síntoma**: tras autorizar correctamente y cerrar el cliente, al volver a abrirlo te pide login de nuevo.

**Causas posibles**:

- El proceso no tiene permisos de escritura en `~/.mcp-auth/`. Verifica con `ls -la ~/.mcp-auth/`.
- Antivirus/security suite borra los tokens al considerarlos sensibles.
- Cliente lanza mcp-remote en sandbox sin acceso al home real (caso poco frecuente).

**Solución**:

```bash
ls -la "$HOME/.mcp-auth/mcp-remote-"*/
# Debe haber al menos un *_tokens.json. Si no, mcp-remote no está pudiendo escribir.
```

Si los tokens existen pero mcp-remote dice "No token data found", revisa que la versión de mcp-remote sea consistente entre arranques (cada versión usa carpeta propia: `mcp-remote-0.1.37/`, `mcp-remote-0.1.40/`, etc.). Si vas saltando versiones por `npx -y`, tendrás que re-autorizar.

Para fijar versión:

```json
{
  "command": "npx",
  "args": ["-y", "mcp-remote@0.1.37", "https://mcp.consensus.app/mcp"]
}
```

## 8. Conflicto entre conector legacy y kit nuevo

**Síntoma**: el agente a veces da resultados Pro (top 20) y otras veces "cuota agotada 30/mes" sin patrón claro.

**Causa**: ambos están activos y el agente alterna.

**Solución**:

1. Ve a [claude.ai/settings/connectors](https://claude.ai/settings/connectors) → **desconecta** "Consensus".
2. En Claude Code/Cursor reinicia el cliente para que el conector legacy desaparezca del listado.
3. A partir de ahí sólo aparecerá `mcp__consensus__search` (el del kit), siempre con tu plan Pro.

## 9. El token caduca durante una conversación larga

**Síntoma**: tras 4 horas activas, las búsquedas empiezan a fallar con 401 / Unauthorized.

**Causa**: el access_token caducó. mcp-remote debería renovarlo con el refresh_token, pero a veces falla.

**Solución**:

```bash
bash tools/check_mcp.sh    # verifica expires_in y refresh_token
```

Si el refresh falló:

```bash
bash tools/reset_oauth.sh
```

Y reinicia el cliente para forzar nueva OAuth (dura 30 segundos).

## 10. Puertos OAuth en redes corporativas / VPN

**Síntoma**: el navegador abre la URL de autorización pero el callback a `localhost:6761` se cuelga indefinidamente.

**Causa**: VPN, proxy o firewall corporativo intercepta el callback.

**Solución**:

- Desactiva temporalmente VPN/proxy mientras completas OAuth.
- Si no es opción, ejecuta el cliente desde una red no corporativa para la auth inicial. Una vez tienes los tokens en `~/.mcp-auth/`, ya no se necesita callback.
