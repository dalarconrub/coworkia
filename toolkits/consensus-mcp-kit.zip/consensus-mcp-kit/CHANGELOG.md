# CHANGELOG — consensus-mcp-kit

## v0.1.0 — extracción inicial

- Plantillas para Cursor (`~/.cursor/mcp.json`) y Claude Code (`~/.claude.json`) con `npx mcp-remote`.
- Plantilla alternativa HTTP directo (sin OAuth, modo anónimo).
- Instalador idempotente bash + PowerShell con backup automático.
- Diagnóstico (`tools/check_mcp`).
- Limpieza OAuth (`tools/reset_oauth`).
- Liberación de puerto callback (`tools/free_oauth_port`).
- Documentación: README + BACKGROUND + TROUBLESHOOTING.
